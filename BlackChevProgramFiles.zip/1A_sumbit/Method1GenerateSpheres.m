function [FinalNSpheres, UnitBrickNSpheres, Positions, Radii, Contacts, ListXmin, ListYmin, ListZmin, ListXmax, ListYmax, ListZmax] = Method1GenerateSpheres(ProbabilityDistr, FaceGoal, BodyGoal, SphereContactParameter, ParentParameter, BrickSideLengths, BrickNumbers)

%Initially there are spheres placed in each corner so there is 4 spheres on
%each face, so the projected area is 4*pi*1^1

output_percent_step=10;

AreaXmin = 4*pi;
AreaXmax = 4*pi;
AreaYmin = 4*pi;
AreaYmax = 4*pi;
AreaZmin = 4*pi;
AreaZmax = 4*pi;


%unlike Method 2, here all the programming is dimensionless
average = mean(ProbabilityDistr);

epsilon = SphereContactParameter; %This is the contact parameter, if particles are within epsilon of eachother they are considered to be in contact
delta = ParentParameter; %This is the parent parameter, if particles are within delta of eachother they are potential parents

rad_mean = 1;
r_max = 3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% numbers of bricks to repeat in each direction
xBricks = BrickNumbers(1);
yBricks = BrickNumbers(2);
zBricks = BrickNumbers(3);

x_min = 0;
y_min = 0;
z_min = 0;

x_max = BrickSideLengths(1)/average;
y_max = BrickSideLengths(2)/average;
z_max = BrickSideLengths(3)/average;



GoalForX = y_max*z_max*FaceGoal; %Proportion of the face covered by spheres (pi*r^2)
GoalForY = x_max*z_max*FaceGoal;
GoalForZ = x_max*y_max*FaceGoal; % Suggested FaceGoal = 0.8 


%%%%%%%Position and Radius of placed particles%%%%%%%%%%%%

Ninit=25; %number of elements to initialze all arrays

Positions = zeros(3,Ninit); %Starting off with 1000 empty spaces to be filled 3, 10000
Radii = zeros(1,Ninit); %Empty radii to be filled 1, 10000

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%Parent particles for unit brick faces%%%%%%%%%%%%%%%%%
%%%Keeps track of which particles can spawn a new sphere on a given face%%

%Since these store indicies they will always be integers

PXmin = uint32(zeros(Ninit,2)); %Large array who's rows store the indicies of parents on Xmin plane 1000->N_initialize
size_PXmin = uint32(0);
PXmax = uint32(zeros(Ninit,2)); %Rows store indicies of parents on Xmax plane
size_PXmax = uint32(0);
PYmin = uint32(zeros(Ninit,2));
size_PYmin = uint32(0);
PYmax = uint32(zeros(Ninit,2));
size_PYmax = uint32(0);
PZmin = uint32(zeros(Ninit,2));
size_PZmin = uint32(0);
PZmax = uint32(zeros(Ninit,2));
size_PZmax = uint32(0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



Contacts = uint32(zeros(Ninit,2)); %Array whos rows are the indicies of particles that are in contact %1000000 -> 15
size_Contacts = uint32(0);

P3 = uint32(zeros(1,3)); %Array whos rows are the 3 indicies of particles that can spaws a sphere in 3d %100000
size_P3 = uint32(0); %Right now there are none

ListXmin = uint32(zeros(Ninit,1)); %Will list index of all spheres on Xmin plane %1000 ->15
num_Xmin = uint32(4);%starts off at 4 bc there are 4 particles on each face
ListXmax = uint32(zeros(Ninit,1)); %Will list index of all spheres on Xmax plane
num_Xmax = uint32(4);
ListYmin = uint32(zeros(Ninit,1)); %Will list index of all spheres on Ymin plane
num_Ymin = uint32(4);
ListYmax = uint32(zeros(Ninit,1)); %Will list index of all spheres on Ymax plane
num_Ymax = uint32(4);
ListZmin = uint32(zeros(Ninit,1)); %Will list index of all spheres on Zmin plane
num_Zmin = uint32(4);
ListZmax = uint32(zeros(Ninit,1)); %Will list index of all spheres on Zmax plane
num_Zmax = uint32(4); 

num_ThrownAway = uint32(0); %indexing number for thrown away spheres
ThrownAway = zeros(Ninit,1); %List of thrown away spheres %10000->15

FinalNSpheres = 8; %Keeps track of the total number of placed spheres, starts at 8 bc there is a sphere in each of the 8 corners




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('--- Starting sphere filling of the specified domain: Method 1 ---');
disp('* Probability distribution and its parameters:');
disp(ProbabilityDistr);
fprintf('* Average sphere radius: %2.5f [physical units]\n', average);
fprintf('* Dimensions of the unit brick [same physical units]: %2.5f x %2.5f x %2.5f\n', x_max, y_max, z_max);
fprintf('* Numbers of unit bricks to be used to define the domain V -- %.0f along x, %2.0f along y, %2.0f along z\n', xBricks, yBricks, zBricks);
fprintf('* Dimensions of the domain V to be filled [same physical units]: %2.5f x %2.5f x %2.5f\n', x_max*xBricks, y_max*yBricks, z_max*zBricks);
fprintf('* Face goal: %2.5f%% of faces to be covered with spheres\n', FaceGoal*100);
fprintf('* Body goal: %2.5f%% of volume to be occupied with spheres\n', BodyGoal*100);
fprintf('* Sphere contact parameter: %2.5f \n', SphereContactParameter);
fprintf('* Parent parameter: %2.5f \n\n', ParentParameter);

disp('--- Filling unit brick edges and faces ... ---');


%% Filling The Corners

Positions(:,1) = [1;1;1]; %First sphere
Radii(1) = 1;
Positions(:,2) = [x_max - 1;1;1];%Second corner
Radii(2) = 1;
Positions(:,3) = [(x_max - 1);(y_max - 1);1];%Third Corner
Radii(3) = 1;
Positions(:,4) = [1;(y_max - 1);1];%4th corner
Radii(4) = 1;
Positions(:,5) = [1;1;(z_max - 1)];%5th corner
Radii(5) = 1;
Positions(:,6) = [(x_max - 1);1;(z_max - 1)];%6th corner
Radii(6) = 1;
Positions(:,7) = [(x_max - 1);(y_max - 1);(z_max - 1)];%7th corner
Radii(7) = 1;
Positions(:,8) = [1;(y_max - 1);(z_max - 1)];%8th corner
Radii(8) = 1;


ListXmin(1:4) = [1, 4, 5, 8]';
ListXmax(1:4) = [2, 3, 6, 7]';
ListYmin(1:4) = [1, 2, 5, 6]';
ListYmax(1:4) = [3, 4, 7, 8]';
ListZmin(1:4) = [1, 2, 3, 4]';
ListZmax(1:4) = [5, 6, 7, 8]';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% Filling the Edges


%Fill edge 1-2
%ParetnsYmin ParentsZmin
%Need to place one ball before fitting can start
FinalNSpheres = 9;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = r_new;
z_new = r_new; %in contact with Ymin and Zmin
x_new = sqrt((r_new + Radii(1))^2-(y_new - Positions(2,1))^2-(z_new - Positions(3,1))^2) + Positions(1,1); %fitting next sphere next to N=1

while isreal(x_new) == false %Ocassionally a r_new results in a complex solution to x_new, these need to be discarded.
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(1))^2-(y_new - Positions(2,1))^2-(z_new - Positions(3,1))^2) + Positions(1,1);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2; %Area of circles on YminFace
AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;

size_PZmin = 1;
PZmin(size_PZmin,:) = [1, 9]; %First row
size_PYmin = 1;
PYmin(size_PYmin,:) = [1, 9];

size_Contacts = 1;
Contacts(size_Contacts,:) = [1, 9]; %First particles in contact are 1 and 9

num_Ymin = num_Ymin + 1;
num_Zmin = num_Zmin + 1;

ListYmin(num_Ymin) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListZmin(num_Zmin) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

%If a new sphere overlaps the corner 2 sphere then the loop will stop.
STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = r_new;
    z_new = r_new;
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    
    while isreal(x_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,2)) < r_new + Radii(2) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,2)) < Radii(FinalNSpheres) + Radii(2) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [2,FinalNSpheres];
           
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [2,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [2,FinalNSpheres;];
        
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(x_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,2)) < r_new + Radii(2) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,2)) < Radii(FinalNSpheres) + Radii(2) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [2,FinalNSpheres];
                    
                    size_PYmin = size_PYmin + 1;
                    PYmin(size_PYmin,:) = [2,FinalNSpheres];
                    
                    size_PZmin = size_PZmin + 1;
                    PZmin(size_PZmin,:) = [2,FinalNSpheres;];
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2; %Area of circles on YminFace
                AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymin = num_Ymin + 1;
                num_Zmin = num_Zmin + 1;
                
                ListYmin(num_Ymin) = FinalNSpheres;
                ListZmin(num_Zmin) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2; %Area of circles on YminFace
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Zmin = num_Zmin + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;

        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2; %Area of circles on YminFace
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Zmin = num_Zmin + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
            
        end
    end
end


%Fill edge 4-3
%PYmax PZmin
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = (y_max - r_new);
z_new = r_new; %in contact with Ymin and Zmin
x_new = sqrt((r_new + Radii(4))^2-(y_new - Positions(2,4))^2-(z_new - Positions(3,4))^2) + Positions(1,4); %fitting next sphere next to N=1

while isreal(x_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(4))^2-(y_new - Positions(2,4))^2-(z_new - Positions(3,4))^2) + Positions(1,4);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2; 
AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;

size_PZmin = size_PZmin + 1;
PZmin(size_PZmin,:) = [4, FinalNSpheres]; %First row
size_PYmax = size_PYmax + 1;
PYmax(size_PYmax,:) = [4, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [4, FinalNSpheres]; %4th particle in contact with N

num_Ymax = num_Ymax + 1;
num_Zmin = num_Zmin + 1;

ListYmax(num_Ymax) = FinalNSpheres; %List showing that particle N in on Ymax plane
ListZmin(num_Zmin) = FinalNSpheres; %List showing that particle N in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = (y_max - r_new);
    z_new = r_new;
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    
    while isreal(x_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,3)) < r_new + Radii(3) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,3)) < Radii(FinalNSpheres) + Radii(3) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [3,FinalNSpheres];
           
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [3,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [3,FinalNSpheres;];
 
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(x_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,3)) < r_new + Radii(3) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,3)) < Radii(FinalNSpheres) + Radii(3) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [3,FinalNSpheres];
                    
                    size_PYmax = size_PYmax + 1;
                    PYmax(size_PYmax,:) = [3,FinalNSpheres];
                    
                    size_PZmin = size_PZmin + 1;
                    PZmin(size_PZmin,:) = [3,FinalNSpheres;];
                
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2; 
                AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymax = num_Ymax + 1;
                num_Zmin = num_Zmin + 1;
                
                ListYmax(num_Ymax) = FinalNSpheres;
                ListZmin(num_Zmin) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2; 
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Zmin = num_Zmin + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
         
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2; 
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Zmin = num_Zmin + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
            
        end
    end
end




%Fill edge 5 -> 6
%ParetnsYmin ParentsZmax
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = r_new;
z_new = (z_max - r_new); %in contact with Ymin and Zmin
x_new = sqrt((r_new + Radii(5))^2-(y_new - Positions(2,5))^2-(z_new - Positions(3,5))^2) + Positions(1,5); %fitting next sphere next to N=1

while isreal(x_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(5))^2-(y_new - Positions(2,5))^2-(z_new - Positions(3,5))^2) + Positions(1,5);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;

size_PZmax = size_PZmax + 1;
PZmax(size_PZmax,:) = [5, FinalNSpheres]; %First row
size_PYmin = size_PYmin + 1;
PYmin(size_PYmin,:) = [5, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [5, FinalNSpheres]; %First particles in contact are 1 and 9

num_Ymin = num_Ymin + 1;
num_Zmax = num_Zmax + 1;

ListYmin(num_Ymin) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListZmax(num_Zmax) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = r_new;
    z_new = (z_max - r_new);
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    
    while isreal(x_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,6)) < r_new + Radii(6) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,6)) < Radii(FinalNSpheres) + Radii(6) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [6,FinalNSpheres];
           
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [6,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [6,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(x_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1);
            end
            
            if norm([x_new;y_new;z_new] - Positions(:,6)) < r_new + Radii(6) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,6)) < Radii(FinalNSpheres) + Radii(6) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [6,FinalNSpheres];
                    
                    size_PYmin = size_PYmin + 1;
                    PYmin(size_PYmin,:) = [6,FinalNSpheres];
                    
                    size_PZmax = size_PZmax + 1;
                    PZmax(size_PZmax,:) = [6,FinalNSpheres;];
              
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
                AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymin = num_Ymin + 1;
                num_Zmax = num_Zmax + 1;
                
                ListYmin(num_Ymin) = FinalNSpheres;
                ListZmax(num_Zmax) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Zmax = num_Zmax + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Zmax = num_Zmax + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        end
    end
end






%Fill edge 8 -> 7
%PYmax PZmax
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = (y_max - r_new);
z_new = (z_max - r_new); %in contact with Ymin and Zmin
x_new = sqrt((r_new + Radii(8))^2-(y_new - Positions(2,8))^2-(z_new - Positions(3,8))^2) + Positions(1,8); %fitting next sphere next to N=1

while isreal(x_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    x_new = sqrt((r_new + Radii(8))^2-(y_new - Positions(2,8))^2-(z_new - Positions(3,8))^2) + Positions(1,8);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;

size_PZmax = size_PZmax + 1;
PZmax(size_PZmax,:) = [8, FinalNSpheres]; %First row
size_PYmax = size_PYmax + 1;
PYmax(size_PYmax,:) = [8, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [8, FinalNSpheres]; %4th particle in contact with N

num_Ymax = num_Ymax + 1;
num_Zmax = num_Zmax + 1;

ListYmax(num_Ymax) = FinalNSpheres; %List showing that particle N in on Ymax plane
ListZmax(num_Zmax) = FinalNSpheres; %List showing that particle N in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = (y_max - r_new);
    z_new = (z_max - r_new);
    x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    
    while isreal(x_new) == false
        r_new = (1/average)*random(ProbabilityDistr);
        x_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(1,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,7)) < r_new + Radii(7) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,7)) < Radii(FinalNSpheres) + Radii(7) + delta %Last particle is close enought for contact with 7
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [7,FinalNSpheres];
           
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [7,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [7,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(x_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                x_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(1,FinalNSpheres-1);
            end
            
            if norm([x_new;y_new;z_new] - Positions(:,7)) < r_new + Radii(7) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,7)) < Radii(FinalNSpheres) + Radii(7) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [7,FinalNSpheres];
                    
                    size_PYmax = size_PYmax + 1;
                    PYmax(size_PYmax,:) = [7,FinalNSpheres];
                    
                    size_PZmax = size_PZmax + 1;
                    PZmax(size_PZmax,:) = [7,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
                AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymax = num_Ymax + 1;
                num_Zmax = num_Zmax + 1;
                
                ListYmax(num_Ymax) = FinalNSpheres;
                ListZmax(num_Zmax) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Zmax = num_Zmax + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Zmax = num_Zmax + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        end
    end
end


%Fill edge 1 -> 4
%ParetnsXmin ParentsZmin
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
x_new = r_new;
z_new = r_new; %in contact with Ymin and Zmin
y_new = sqrt((r_new + Radii(1))^2-(x_new - Positions(1,1))^2-(z_new - Positions(3,1))^2) + Positions(2,1); %fitting next sphere next to N=1

while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(1))^2-(x_new - Positions(1,1))^2-(z_new - Positions(3,1))^2) + Positions(2,1);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;

size_PZmin = size_PZmin + 1;
PZmin(size_PZmin,:) = [1, FinalNSpheres]; 
size_PXmin = size_PXmin + 1;
PXmin(size_PXmin,:) = [1, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [1, FinalNSpheres]; %First particles in contact are 1 and 9

num_Xmin = num_Xmin + 1;
num_Zmin = num_Zmin + 1;

ListXmin(num_Xmin) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListZmin(num_Zmin) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    x_new = r_new;
    z_new = r_new;
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    
    while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,4)) < r_new + Radii(4) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,4)) < Radii(FinalNSpheres) + Radii(4) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [4,FinalNSpheres];
           
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [4,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [4,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(y_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1);
            end
            
            if norm([x_new;y_new;z_new] - Positions(:,4)) < r_new + Radii(4) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,4)) < Radii(FinalNSpheres) + Radii(4) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [4,FinalNSpheres];
                    
                    size_PXmin = size_PXmin + 1;
                    PXmin(size_PXmin,:) = [4,FinalNSpheres];
                    
                    size_PZmin = size_PZmin + 1;
                    PZmin(size_PZmin,:) = [4,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
                AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Xmin = num_Xmin + 1;
                num_Zmin = num_Zmin + 1;
                
                ListXmin(num_Xmin) = FinalNSpheres;
                ListZmin(num_Zmin) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Xmin = num_Xmin + 1;
            num_Zmin = num_Zmin + 1;
            
            ListXmin(num_Xmin) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Xmin = num_Xmin + 1;
            num_Zmin = num_Zmin + 1;
            
            ListXmin(num_Xmin) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
            
        end
    end
end

%Fill edge 2 -> 3
%ParetnsXmax ParentsZmin
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
x_new = (x_max - r_new);
z_new = r_new; %in contact with Ymin and Zmin
y_new = sqrt((r_new + Radii(2))^2-(x_new - Positions(1,2))^2-(z_new - Positions(3,2))^2) + Positions(2,2); %fitting next sphere next to N=1

while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(2))^2-(x_new - Positions(1,2))^2-(z_new - Positions(3,2))^2) + Positions(2,2);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;

size_PZmin = size_PZmin + 1;
PZmin(size_PZmin,:) = [2, FinalNSpheres]; 
size_PXmax = size_PXmax + 1;
PXmax(size_PXmax,:) = [2, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [2, FinalNSpheres]; 

num_Xmax = num_Xmax + 1;
num_Zmin = num_Zmin + 1;

ListXmax(num_Xmax) = FinalNSpheres; %List showing that particle N in on Ymin plane
ListZmin(num_Zmin) = FinalNSpheres; %List showing that particle N in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    x_new = (x_max - r_new);
    z_new = r_new;
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    
    while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,3)) < r_new + Radii(3) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,3)) < Radii(FinalNSpheres) + Radii(3) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [3,FinalNSpheres];
           
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [3,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [3,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(y_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,3)) < r_new + Radii(3) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,3)) < Radii(FinalNSpheres) + Radii(3) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [3,FinalNSpheres];
                    
                    size_PXmax = size_PXmax + 1;
                    PXmax(size_PXmax,:) = [3,FinalNSpheres];
                    
                    size_PZmin = size_PZmin + 1;
                    PZmin(size_PZmin,:) = [3,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
                AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Xmax = num_Xmax + 1;
                num_Zmin = num_Zmin + 1;
                
                ListXmax(num_Xmax) = FinalNSpheres;
                ListZmin(num_Zmin) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmin = size_PZmin + 1;
                PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Xmax = num_Xmax + 1;
            num_Zmin = num_Zmin + 1;
            
            ListXmax(num_Xmax) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmin = size_PZmin + 1;
            PZmin(size_PZmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Xmax = num_Xmax + 1;
            num_Zmin = num_Zmin + 1;
            
            ListXmax(num_Xmax) = FinalNSpheres;
            ListZmin(num_Zmin) = FinalNSpheres;
            
        end
    end
end


%Fill edge 5 -> 8
%ParetnsXmin ParentsZmax
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
x_new = r_new;
z_new = (z_max - r_new); %in contact with Ymin and Zmin
y_new = sqrt((r_new + Radii(5))^2-(x_new - Positions(1,5))^2-(z_new - Positions(3,5))^2) + Positions(2,5); %fitting next sphere next to N=1

while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(5))^2-(x_new - Positions(1,5))^2-(z_new - Positions(3,5))^2) + Positions(2,5);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;

size_PZmax = size_PZmax + 1;
PZmax(size_PZmax,:) = [5, FinalNSpheres]; 
size_PXmin = size_PXmin + 1;
PXmin(size_PXmin,:) = [5, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [5, FinalNSpheres]; %First particles in contact are 1 and 9

num_Xmin = num_Xmin + 1;
num_Zmax = num_Zmax + 1;

ListXmin(num_Xmin) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListZmax(num_Zmax) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    x_new = r_new;
    z_new = (z_max - r_new);
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    
    while isreal(y_new) == false
        r_new = (1/average)*random(ProbabilityDistr);
        y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    end
    
    
    
    if norm([x_new;y_new;z_new] - Positions(:,8)) < r_new + Radii(8) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,8)) < Radii(FinalNSpheres) + Radii(8) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [8,FinalNSpheres];
           
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [8,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [8,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(y_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1);
            end
            
            if norm([x_new;y_new;z_new] - Positions(:,8)) < r_new + Radii(8) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,8)) < Radii(FinalNSpheres) + Radii(8) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [8,FinalNSpheres];
                    
                    size_PXmin = size_PXmin + 1;
                    PXmin(size_PXmin,:) = [8,FinalNSpheres];
                    
                    size_PZmax = size_PZmax + 1;
                    PZmax(size_PZmax,:) = [8,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
                AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
                
                num_Xmin = num_Xmin + 1;
                num_Zmax = num_Zmax + 1;
                
                ListXmin(num_Xmin) = FinalNSpheres;
                ListZmax(num_Zmax) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Xmin = num_Xmin + 1;
            num_Zmax = num_Zmax + 1;
            
            ListXmin(num_Xmin) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Xmin = num_Xmin + 1;
            num_Zmax = num_Zmax + 1;
            
            ListXmin(num_Xmin) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        end
    end
end


%Fill edge 6 -> 7
%ParetnsXmax ParentsZmax
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
x_new = (x_max - r_new);
z_new = (z_max - r_new); %in contact with Ymin and Zmin
y_new = sqrt((r_new + Radii(6))^2-(x_new - Positions(1,6))^2-(z_new - Positions(3,6))^2) + Positions(2,6); %fitting next sphere next to N=1

while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(6))^2-(x_new - Positions(1,6))^2-(z_new - Positions(3,6))^2) + Positions(2,6);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;

size_PZmax = size_PZmax + 1;
PZmax(size_PZmax,:) = [6, FinalNSpheres]; 
size_PXmax = size_PXmax + 1;
PXmax(size_PXmax,:) = [6, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [6, FinalNSpheres]; 

num_Xmax = num_Xmax + 1;
num_Zmax = num_Zmax + 1;

ListXmax(num_Xmax) = FinalNSpheres; %List showing that particle N in on Ymin plane
ListZmax(num_Zmax) = FinalNSpheres; %List showing that particle N in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    x_new = (x_max - r_new);
    z_new = (z_max - r_new);
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    
    while isreal(y_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    y_new = sqrt((r_new + Radii(FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2-(z_new - Positions(3,FinalNSpheres))^2) + Positions(2,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,7)) < r_new + Radii(7) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,7)) < Radii(FinalNSpheres) + Radii(7) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [7,FinalNSpheres];
           
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [7,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [7,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(y_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                y_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2-(z_new - Positions(3,FinalNSpheres-1))^2) + Positions(2,FinalNSpheres-1);
            end
            
            if norm([x_new;y_new;z_new] - Positions(:,7)) < r_new + Radii(7) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,7)) < Radii(FinalNSpheres) + Radii(7) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [7,FinalNSpheres];
                    
                    size_PXmax = size_PXmax + 1;
                    PXmax(size_PXmax,:) = [7,FinalNSpheres];
                    
                    size_PZmax = size_PZmax + 1;
                    PZmax(size_PZmax,:) = [7,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
                AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
                
                num_Xmax = num_Xmax + 1;
                num_Zmax = num_Zmax + 1;
                
                ListXmax(num_Xmax) = FinalNSpheres;
                ListZmax(num_Zmax) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PZmax = size_PZmax + 1;
                PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Xmax = num_Xmax + 1;
            num_Zmax = num_Zmax + 1;
            
            ListXmax(num_Xmax) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PZmax = size_PZmax + 1;
            PZmax(size_PZmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Xmax = num_Xmax + 1;
            num_Zmax = num_Zmax + 1;
            
            ListXmax(num_Xmax) = FinalNSpheres;
            ListZmax(num_Zmax) = FinalNSpheres;
            
        end
    end
end


%Fill edge 1 -> 5
%ParetnsYmin ParentsXmin
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = r_new;
x_new = r_new; %in contact with Ymin and Xmin
z_new = sqrt((r_new + Radii(1))^2-(y_new - Positions(2,1))^2-(x_new - Positions(1,1))^2) + Positions(3,1); %fitting next sphere next to N=1

while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(1))^2-(y_new - Positions(2,1))^2-(x_new - Positions(1,1))^2) + Positions(3,1);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;

size_PXmin = size_PXmin + 1;
PXmin(size_PXmin,:) = [1, FinalNSpheres]; %First row
size_PYmin = size_PYmin + 1;
PYmin(size_PYmin,:) = [1, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [1, FinalNSpheres]; %First particles in contact are 1 and 9

num_Ymin = num_Ymin + 1;
num_Xmin = num_Xmin + 1;

ListYmin(num_Ymin) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListXmin(num_Xmin) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = r_new;
    x_new = r_new;
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    
    while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,5)) < r_new + Radii(5) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,5)) < Radii(FinalNSpheres) + Radii(5) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [5,FinalNSpheres];
           
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [5,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [5,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(z_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,5)) < r_new + Radii(5) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,5)) < Radii(FinalNSpheres) + Radii(5) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [5,FinalNSpheres];
                    
                    size_PYmin = size_PYmin + 1;
                    PYmin(size_PYmin,:) = [5,FinalNSpheres];
                    
                    size_PXmin = size_PXmin + 1;
                    PXmin(size_PXmin,:) = [5,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
                AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymin = num_Ymin + 1;
                num_Xmin = num_Xmin + 1;
                
                ListYmin(num_Ymin) = FinalNSpheres;
                ListXmin(num_Xmin) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Xmin = num_Xmin + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListXmin(num_Xmin) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Xmin = num_Xmin + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListXmin(num_Xmin) = FinalNSpheres;
            
        end
    end
end


%Fill edge 2 -> 6
%ParetnsYmin ParentsXmax
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = r_new;
x_new = (x_max - r_new); %in contact with Ymin and Xmin
z_new = sqrt((r_new + Radii(2))^2-(y_new - Positions(2,2))^2-(x_new - Positions(1,2))^2) + Positions(3,2); %fitting next sphere next to N=1

while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(2))^2-(y_new - Positions(2,2))^2-(x_new - Positions(1,2))^2) + Positions(3,2);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;

size_PXmax = size_PXmax + 1;
PXmax(size_PXmax,:) = [2, FinalNSpheres]; %First row
size_PYmin = size_PYmin + 1;
PYmin(size_PYmin,:) = [2, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [2, FinalNSpheres]; %First particles in contact are 1 and 9

num_Ymin = num_Ymin + 1;
num_Xmax = num_Xmax + 1;

ListYmin(num_Ymin) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListXmax(num_Xmax) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = r_new;
    x_new = (x_max - r_new);
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    
    while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,6)) < r_new + Radii(6) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,6)) < Radii(FinalNSpheres) + Radii(6) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [6,FinalNSpheres];
           
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [6,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [6,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(z_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,6)) < r_new + Radii(6) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,6)) < Radii(FinalNSpheres) + Radii(6) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [6,FinalNSpheres];
                    
                    size_PYmin = size_PYmin + 1;
                    PYmin(size_PYmin,:) = [6,FinalNSpheres];
                    
                    size_PXmax = size_PXmax + 1;
                    PXmax(size_PXmax,:) = [6,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
                AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymin = num_Ymin + 1;
                num_Xmax = num_Xmax + 1;
                
                ListYmin(num_Ymin) = FinalNSpheres;
                ListXmax(num_Xmax) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmin = size_PYmin + 1;
                PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Xmax = num_Xmax + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListXmax(num_Xmax) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmin = size_PYmin + 1;
            PYmin(size_PYmin,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymin = num_Ymin + 1;
            num_Xmax = num_Xmax + 1;
            
            ListYmin(num_Ymin) = FinalNSpheres;
            ListXmax(num_Xmax) = FinalNSpheres;
            
        end
    end
end


%Fill edge 3 -> 7
%ParetnsYmax ParentsXmax
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = (y_max - r_new);
x_new = (x_max - r_new); %in contact with Ymin and Xmin
z_new = sqrt((r_new + Radii(3))^2-(y_new - Positions(2,3))^2-(x_new - Positions(1,3))^2) + Positions(3,3); %fitting next sphere next to N=1

while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(3))^2-(y_new - Positions(2,3))^2-(x_new - Positions(1,3))^2) + Positions(3,3);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;

size_PXmax = size_PXmax + 1;
PXmax(size_PXmax,:) = [3, FinalNSpheres]; %First row
size_PYmax = size_PYmax + 1;
PYmax(size_PYmax,:) = [3, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [3, FinalNSpheres]; %First particles in contact are 1 and 9

num_Ymax = num_Ymax + 1;
num_Xmax = num_Xmax + 1;

ListYmax(num_Ymax) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListXmax(num_Xmax) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = (y_max - r_new);
    x_new = (x_max - r_new);
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    
    while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,7)) < r_new + Radii(7) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,7)) < Radii(FinalNSpheres) + Radii(7) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [7,FinalNSpheres];
           
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [7,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [7,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(z_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,7)) < r_new + Radii(7) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,7)) < Radii(FinalNSpheres) + Radii(7) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [7,FinalNSpheres];
                    
                    size_PYmax = size_PYmax + 1;
                    PYmax(size_PYmax,:) = [7,FinalNSpheres];
                    
                    size_PXmax = size_PXmax + 1;
                    PXmax(size_PXmax,:) = [7,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
                AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymax = num_Ymax + 1;
                num_Xmax = num_Xmax + 1;
                
                ListYmax(num_Ymax) = FinalNSpheres;
                ListXmax(num_Xmax) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmax = size_PXmax + 1;
                PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Xmax = num_Xmax + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListXmax(num_Xmax) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2; 
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmax = size_PXmax + 1;
            PXmax(size_PXmax,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Xmax = num_Xmax + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListXmax(num_Xmax) = FinalNSpheres;
            
        end
    end
end


%Fill edge 4 -> 8
%ParetnsYmax ParentsXmin
%Need to place one ball before fitting can start
FinalNSpheres = FinalNSpheres+1;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit
y_new = (y_max - r_new);
x_new = r_new; %in contact with Ymin and Xmin
z_new = sqrt((r_new + Radii(4))^2-(y_new - Positions(2,4))^2-(x_new - Positions(1,4))^2) + Positions(3,4); %fitting next sphere next to N=1

while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(4))^2-(y_new - Positions(2,4))^2-(x_new - Positions(1,4))^2) + Positions(3,4);
end

Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
Radii(FinalNSpheres) = r_new;

AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;

size_PXmin = size_PXmin + 1;
PXmin(size_PXmin,:) = [4, FinalNSpheres]; %First row
size_PYmax = size_PYmax + 1;
PYmax(size_PYmax,:) = [4, FinalNSpheres];

size_Contacts = size_Contacts + 1;
Contacts(size_Contacts,:) = [4, FinalNSpheres]; %First particles in contact are 1 and 9

num_Ymax = num_Ymax + 1;
num_Xmin = num_Xmin + 1;

ListYmax(num_Ymax) = FinalNSpheres; %List showing that particle 9 in on Ymin plane
ListXmin(num_Xmin) = FinalNSpheres; %List showing that particle 9 in on Zmin plane

STOP = false;
r_new = (1/average)*random(ProbabilityDistr); %sphere to be fit

while STOP == false
    
    y_new = (y_max - r_new);
    x_new = r_new;
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    
    while isreal(z_new) == false
    r_new = (1/average)*random(ProbabilityDistr);
    z_new = sqrt((r_new + Radii(FinalNSpheres))^2-(y_new - Positions(2,FinalNSpheres))^2-(x_new - Positions(1,FinalNSpheres))^2) + Positions(3,FinalNSpheres);
    end
    
    
    if norm([x_new;y_new;z_new] - Positions(:,8)) < r_new + Radii(8) - epsilon %Sphere doesn't fit
        STOP = true;
        %Need to check if this is in contact with stopper sphere
        
        if norm(Positions(:,FinalNSpheres) - Positions(:,8)) < Radii(FinalNSpheres) + Radii(8) + delta %Last particle is close enought for contact with 2
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [8,FinalNSpheres];
           
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [8,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [8,FinalNSpheres;];
            
        end
    else %Sphere fit
        if norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) - epsilon %Sphere overlaps with next neighbour
            
            z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1); %Need to find placement w/resp to N-1
            
            while isreal(z_new) == false
                r_new = (1/average)*random(ProbabilityDistr);
                z_new = sqrt((r_new + Radii(FinalNSpheres-1))^2-(y_new - Positions(2,FinalNSpheres-1))^2-(x_new - Positions(1,FinalNSpheres-1))^2) + Positions(3,FinalNSpheres-1);
            end
            
            
            if norm([x_new;y_new;z_new] - Positions(:,8)) < r_new + Radii(8) - epsilon %sphere doesn't fit
                STOP = true;
                
                %Need to check if this is in contact with stopper sphere
                
                if norm(Positions(:,FinalNSpheres) - Positions(:,8)) < Radii(FinalNSpheres) + Radii(8) + delta %Last particle is close enought for contact with 2
                    
                    size_Contacts = size_Contacts + 1;
                    Contacts(size_Contacts,:) = [8,FinalNSpheres];
                    
                    size_PYmax = size_PYmax + 1;
                    PYmax(size_PYmax,:) = [8,FinalNSpheres];
                    
                    size_PXmin = size_PXmin + 1;
                    PXmin(size_PXmin,:) = [8,FinalNSpheres;];
                    
                end
                
            else  %Sphere fits
                FinalNSpheres = FinalNSpheres+1;
                Radii(FinalNSpheres) = r_new;
                Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
                
                AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
                AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
                
                num_Ymax = num_Ymax + 1;
                num_Xmin = num_Xmin + 1;
                
                ListYmax(num_Ymax) = FinalNSpheres;
                ListXmin(num_Xmin) = FinalNSpheres;
                
                r_new = (1/average)*random(ProbabilityDistr);
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres;];
                
                size_Contacts = size_Contacts + 1;
                Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PYmax = size_PYmax + 1;
                PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
                
                size_PXmin = size_PXmin + 1;
                PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres;];
                
            end
            
        elseif norm([x_new;y_new;z_new] - Positions(:,FinalNSpheres-1)) < r_new + Radii(FinalNSpheres-1) + delta %In contact and parents with N-1
            
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-2,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-2,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Xmin = num_Xmin + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListXmin(num_Xmin) = FinalNSpheres;
            
        else %Not in contact nor Parents with N-2
            FinalNSpheres = FinalNSpheres+1;
            Radii(FinalNSpheres) = r_new;
            Positions(:,FinalNSpheres) = [x_new;y_new;z_new];
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2; 
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
            r_new = (1/average)*random(ProbabilityDistr);
            
            size_Contacts = size_Contacts + 1;
            Contacts(size_Contacts,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PYmax = size_PYmax + 1;
            PYmax(size_PYmax,:) = [FinalNSpheres-1,FinalNSpheres];
            
            size_PXmin = size_PXmin + 1;
            PXmin(size_PXmin,:) = [FinalNSpheres-1,FinalNSpheres;];
            
            
            num_Ymax = num_Ymax + 1;
            num_Xmin = num_Xmin + 1;
            
            ListYmax(num_Ymax) = FinalNSpheres;
            ListXmin(num_Xmin) = FinalNSpheres;
            
        end
    end
end


%%%%%%%%%%%%%%%%%%% -- edge generation finished - %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('--- Unit brick edge generation finished ---');


%% Filling The Faces

ActualAreas=0; % (total sum of pi*r^2 of all spheres on faces)
%Zmin Face

prev_percent=0;

while AreaZmin < GoalForZ
    r_new = (1/average)*random(ProbabilityDistr);
    FAIL = uint16(0);
    
    for count = 1:size_PZmin %Going through list of parents on Zmin face
       
        i = PZmin(count,1); j = PZmin(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;0;1]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M1Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,PZmin,size_PZmin,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PZmin,size_PZmin,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M1Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,PZmin,size_PZmin,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PZmin,size_PZmin,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot
                
                r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
                num_Zmin = num_Zmin + 1; %Account for the added sphere on Zmin face
                ListZmin(num_Zmin) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2; 
                
            end
            
        else %Particle fit in 1st spot
            
            r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
            num_Zmin = num_Zmin + 1; %Account for the added sphere on Zmin face
            ListZmin(num_Zmin) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaZmin = AreaZmin + pi*(Radii(FinalNSpheres))^2;
        end
        
        if AreaZmin > GoalForZ %If condition is met in middle of cycle this wil break it
           break 
        end
        
        if FAIL >= size_PZmin %Tried every set of parents on Zmin face
            FAIL = 0;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new;
            r_new = (1/average)*random(ProbabilityDistr); %Keeping track of thrown away spheres
        end
        
    end
    
    ratioZmin = AreaZmin/GoalForZ; 
    
    percent=100*ratioZmin;
    percent = round( min( [100, percent]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the z-min face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end

    
end
ActualAreas=ActualAreas+AreaZmin;


%Zmax Face

prev_percent=0;

while AreaZmax < GoalForZ
    r_new = (1/average)*random(ProbabilityDistr);
    FAIL = uint16(0);
    
    for count = 1:size_PZmax %Going through list of parents on Zmax face
       
        i = PZmax(count,1); j = PZmax(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;0;1]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M1Position2Zmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,z_max);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,PZmax,size_PZmax,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PZmax,size_PZmax,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M1Position2Zmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,z_max);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,PZmax,size_PZmax,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PZmax,size_PZmax,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot
                
                r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
                num_Zmax = num_Zmax + 1; %Account for the added sphere on Zmin face
                ListZmax(num_Zmax) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
                
            end
            
        else %Particle fit in 1st spot
            
            r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
            num_Zmax = num_Zmax + 1; %Account for the added sphere on Zmin face
            ListZmax(num_Zmax) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaZmax = AreaZmax + pi*(Radii(FinalNSpheres))^2;
            
        end
        
        if AreaZmax > GoalForZ %If condition is met in middle of cycle this wil break it
           break 
        end
        
        if FAIL >= size_PZmax %Tried every set of parents on Zmin face
            FAIL = 0;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new;
            r_new = (1/average)*random(ProbabilityDistr); %Keeping track of thrown away spheres
        end
        
    end
    
    ratioZmax = AreaZmax/GoalForZ;
    
%    disp(['Generating spheres along the z-max face ',num2str(100*ratioZmax), '% complete'])
    percent=100*ratioZmax;
    percent = round( min( [100, percent]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the z-max face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end

    
end
ActualAreas=ActualAreas+AreaZmax;


%Xmin Face

prev_percent=0;

while AreaXmin < GoalForX
    r_new = (1/average)*random(ProbabilityDistr);
    FAIL = uint16(0);
    
    for count = 1:size_PXmin %Going through list of parents on Zmin face
       
        i = PXmin(count,1); j = PXmin(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[1;0;0]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M1Position2Xmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,PXmin,size_PXmin,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PXmin,size_PXmin,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M1Position2Xmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,PXmin,size_PXmin,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PXmin,size_PXmin,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot
                
                r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
                num_Xmin = num_Xmin + 1; %Account for the added sphere on Zmin face
                ListXmin(num_Xmin) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2;
                
            end
            
        else %Particle fit in 1st spot
            
            r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
            num_Xmin = num_Xmin + 1; %Account for the added sphere on Zmin face
            ListXmin(num_Xmin) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaXmin = AreaXmin + pi*(Radii(FinalNSpheres))^2;
            
        end
        
        if AreaXmin > GoalForX %If condition is met in middle of cycle this wil break it
           break 
        end
        
        if FAIL >= size_PXmin %Tried every set of parents on Zmin face
            FAIL = 0;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new;
            r_new = (1/average)*random(ProbabilityDistr); %Keeping track of thrown away spheres
        end
    end
    ratioXmin = AreaXmin/GoalForX;
    
    percent=100*ratioXmin;
    percent = round( min( [100, percent]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the x-min face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
%    disp(['Generating spheres along the x-min face ',num2str(10*ratioXmin), '% complete'])
end

ActualAreas=ActualAreas+AreaXmin;


%Xmax Face

prev_percent=0;

while AreaXmax < GoalForX
    r_new = (1/average)*random(ProbabilityDistr);
    FAIL = uint16(0);
    
    for count = 1:size_PXmax %Going through list of parents on Zmax face
       
        i = PXmax(count,1); j = PXmax(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[1;0;0]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M1Position2Xmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,x_max);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,PXmax,size_PXmax,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PXmax,size_PXmax,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M1Position2Xmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,x_max);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,PXmax,size_PXmax,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PXmax,size_PXmax,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot
                
                r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
                num_Xmax = num_Xmax + 1; %Account for the added sphere on Zmin face
                ListXmax(num_Xmax) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2;
                
            end
            
        else %Particle fit in 1st spot
            
            r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
            num_Xmax = num_Xmax + 1; %Account for the added sphere on Zmin face
            ListXmax(num_Xmax) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaXmax = AreaXmax + pi*(Radii(FinalNSpheres))^2;
        end
        
        if AreaXmax > GoalForX %If condition is met in middle of cycle this wil break it
           break 
        end
        
        if FAIL >= size_PXmax %Tried every set of parents on Zmin face
            FAIL = 0;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new;
            r_new = (1/average)*random(ProbabilityDistr); %Keeping track of thrown away spheres
        end
    end 
    ratioXmax = AreaXmax/GoalForX;

    percent=100*ratioXmax;
    percent = round( min( [100, percent]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the x-max face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end

    %disp(['Generating spheres along the x-max face ',num2str(100*ratioXmax), '% complete'])
end

ActualAreas=ActualAreas+AreaXmax;


%Ymin Face

prev_percent=0;

while AreaYmin < GoalForY
    r_new = (1/average)*random(ProbabilityDistr);
    FAIL = uint16(0);
    
    for count = 1:size_PYmin %Going through list of parents on Zmin face
       
        i = PYmin(count,1); j = PYmin(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;1;0]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M1Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,PYmin,size_PYmin,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PYmin,size_PYmin,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M1Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,PYmin,size_PYmin,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PYmin,size_PYmin,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot
                
                r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
                num_Ymin = num_Ymin + 1; %Account for the added sphere on Zmin face
                ListYmin(num_Ymin) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
                
            end
            
        else %Particle fit in 1st spot
            
            r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
            num_Ymin = num_Ymin + 1; %Account for the added sphere on Zmin face
            ListYmin(num_Ymin) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaYmin = AreaYmin + pi*(Radii(FinalNSpheres))^2;
            
        end
        
        if AreaYmin > GoalForY %If condition is met in middle of cycle this wil break it
           break 
        end
        
        if FAIL >= size_PYmin %Tried every set of parents on Zmin face
            FAIL = 0;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new;
            r_new = (1/average)*random(ProbabilityDistr); %Keeping track of thrown away spheres
        end
    end
    ratioYmin = AreaYmin/GoalForY;
    
    %disp(['Generating spheres along the y-min face ',num2str(100*ratioYmin), '% complete'])
    percent=100*ratioYmin;
    percent = round( min( [100, percent]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the y-min face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end

ActualAreas=ActualAreas+AreaYmin;


%Ymax Face

prev_percent=0;

while AreaYmax < GoalForY
    r_new = (1/average)*random(ProbabilityDistr);
    FAIL = uint16(0);
    
    for count = 1:size_PYmax %Going through list of parents on Zmax face
       
        i = PYmax(count,1); j = PYmax(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;1;0]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M1Position2Ymax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,y_max);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,PYmax,size_PYmax,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PYmax,size_PYmax,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M1Position2Ymax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,y_max);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,PYmax,size_PYmax,Contacts,size_Contacts,P3,size_P3] = M1Search2D(p_new,r_new,Positions,Radii,FinalNSpheres,PYmax,size_PYmax,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot
                
                r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
                num_Ymax = num_Ymax + 1; %Account for the added sphere on Zmin face
                ListYmax(num_Ymax) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
                
            end
            
        else %Particle fit in 1st spot
            
            r_new = (1/average)*random(ProbabilityDistr); %Need tp grab new sphere
            num_Ymax = num_Ymax + 1; %Account for the added sphere on Zmin face
            ListYmax(num_Ymax) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaYmax = AreaYmax + pi*(Radii(FinalNSpheres))^2;
            
        end
        
        if AreaYmax > GoalForY %If condition is met in middle of cycle this wil break it
           break 
        end
        
        if FAIL >= size_PYmax %Tried every set of parents on Zmin face
            FAIL = 0;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new;
            r_new = (1/average)*random(ProbabilityDistr); %Keeping track of thrown away spheres
        end
    end 
    ratioYmax = AreaYmax/GoalForY;
    
    %disp(['Generating spheres along the y-max face ',num2str(100*ratioYmax), '% complete'])
    percent=100*ratioYmax;
    percent = round( min( [100, percent]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the y-max face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end

ActualAreas=ActualAreas+AreaYmax;

    
disp('--- Unit brick face generation complete ---');

TotalFaceAreaRequested = 2*(GoalForX+GoalForY+GoalForZ);

fprintf('* Covered face area: %2.5f%% of the specified face goal\n\n', 100*ActualAreas/TotalFaceAreaRequested);


%% Filling The Body

disp('--- Filling unit brick volume ... ---');

TotalVolume = x_max*y_max*z_max;
V = (4*pi/3)*(Radii.^3); %Volume of all placed spheres
SphereVolume = sum(V);

r_new = (1/average)*random(ProbabilityDistr); %first radius we'll try to fit
FAIL = 0;

prev_percent=0;

while (SphereVolume)/(TotalVolume) < BodyGoal%What percentage of the unit brick will be spheres 0.5
    
    for count = 1:size_P3
        
        NEXT = false; NEXT2 = false; %Resetting the NEXT values with new paretns, will only become true if they p_new fails test
        I = P3(count,1); J = P3(count,2); K = P3(count,3);
        
        Centeroid = [(Positions(1,I) + Positions(1,J) + Positions(1,K))/3; (Positions(2,I) + Positions(2,J) + Positions(2,K))/3; (Positions(3,I) + Positions(3,J) + Positions(3,K))/3;];
        P_ij = (Positions(:,J) - Positions(:,I))/norm(Positions(:,J) - Positions(:,I));
        P_ik = (Positions(:,K) - Positions(:,I))/norm(Positions(:,K) - Positions(:,I));
        t_hat = cross(P_ij, P_ik);
        
        x_0 = Centeroid + (r_new)*(t_hat);
        
        fun = @(x) M1Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        %Checking if particle fits
        [NEXT,FinalNSpheres,Radii,Positions,Contacts,size_Contacts,P3,size_P3] = M1Search3D(p_new,r_new,Positions,Radii,FinalNSpheres,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit in 1st spot
            
            x_0 = Centeroid + (r_new)*(-t_hat); %x_0 is on opposite side of plane,
            
            fun = @(x) M1Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Checking if new particle fits
            [NEXT2,FinalNSpheres,Radii,Positions,Contacts,size_Contacts,P3,size_P3] = M1Search3D(p_new,r_new,Positions,Radii,FinalNSpheres,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta);
            
            if NEXT2 == true %Particle didnt fit in 2nd spot
                FAIL = FAIL + 1;
            else %Particle fit in 2nd spot
                SphereVolume = SphereVolume + (4*pi/3)*((Radii(FinalNSpheres)).^3); %New sphere is added to the total sphere volume
                r_new = (1/average)*random(ProbabilityDistr);
                FAIL = 0; %Since p_new fit need to reset FAIL count
            end
        else %Particle fit in 1st spot
            SphereVolume = SphereVolume + (4*pi/3)*((Radii(FinalNSpheres)).^3); %New sphere is added to the total sphere volume
            r_new = (1/average)*random(ProbabilityDistr);
            FAIL = 0; %Since p_new fit need to reset FAIL count
        end
        
        
        if FAIL >= size_P3 %Tried Every Set of Parents
           num_ThrownAway = num_ThrownAway + 1; %index and count of spheres thrown away
           ThrownAway(num_ThrownAway) = r_new; %Keep track of sphere discarded
           r_new = (1/average)*random(ProbabilityDistr);
           FAIL = 0; %Reset FAIL count
        end
        
        if (SphereVolume)/(TotalVolume) >= BodyGoal
           break 
        end
         
    end
    
    ratio = (SphereVolume)/(TotalVolume);
    perc = ratio/BodyGoal;
    
%    disp(['Generating spheres in the domain bulk ',num2str(100*perc), '% complete'])

    percent = round( min( [100, perc*100]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres in the domain bulk ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
   
end

Radii = Radii(1:FinalNSpheres);
Positions = Positions(:,1:FinalNSpheres); %Removing any unused entries

disp('--- Unit brick volume generation complete ---');

fprintf('* Covered volume: %2.5f%% of specified body goal\n\n', perc*100);

disp('--- Filling total volume ... ---');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Brick Joining in X

num_Ymin = double(num_Ymin);
num_Ymax = double(num_Ymax);
num_Xmin = double(num_Xmin);
num_Xmax = double(num_Xmax);
num_Zmin = double(num_Zmin);
num_Zmax = double(num_Zmax); %Will grow with every iteration

size_ListXmin = double(num_Xmin);
size_ListXmax = double(num_Xmax);
size_ListYmin = double(num_Ymin);
size_ListYmax = double(num_Ymax);
size_ListZmin = double(num_Zmin); %Initial size
size_ListZmax = double(num_Zmax);

size_Contacts = double(size_Contacts);
size_Contacts_constant = size_Contacts;

ListXmin = double(ListXmin);
ListXmax = double(ListXmax);
ListYmin = double(ListYmin);
ListYmax = double(ListYmax);
ListZmin = double(ListZmin);
ListZmax = double(ListZmax);


FinalNSpheres = double(FinalNSpheres);
UnitBrickNSpheres = FinalNSpheres;

P_even = Positions(:,1:FinalNSpheres);
P_odd = abs([x_max;0;0] - Positions(:,1:FinalNSpheres));

for count = 1:(xBricks-1) %This will be xBricks Bricks total 
    
 
    if mod(count,2) == 0 %Even
        FaceContacts = ListXmin(1:num_Xmin) + (count)*UnitBrickNSpheres;
        size_FaceContacts = num_Xmin;
        
        Positions(:,(FinalNSpheres+1):(FinalNSpheres + UnitBrickNSpheres)) = P_even + (count)*[x_max;0;0];
    else %Odd
        
        FaceContacts = ListXmax(1:num_Xmax) + (count)*UnitBrickNSpheres;
        size_FaceContacts = num_Xmax;
        
        Positions(:,(FinalNSpheres+1):(FinalNSpheres+UnitBrickNSpheres)) = P_odd + (count)*[x_max;0;0];
        
    end
   
    
    Contacts((size_Contacts + 1):(size_Contacts + size_FaceContacts),:) = [(FaceContacts - UnitBrickNSpheres),FaceContacts];
    size_Contacts = size_Contacts + size_FaceContacts;
    
    Contacts((size_Contacts+1):(size_Contacts + size_Contacts_constant),:) = Contacts(1:size_Contacts_constant,:) + (count)*(UnitBrickNSpheres);
    size_Contacts = size_Contacts + size_Contacts_constant;
    
    
    Radii((FinalNSpheres+1):(FinalNSpheres+UnitBrickNSpheres)) = Radii(1:UnitBrickNSpheres);
    
    
    ListYmin((num_Ymin + 1):(num_Ymin + size_ListYmin)) = ListYmin(1:size_ListYmin) + (count)*(UnitBrickNSpheres);
    num_Ymin = num_Ymin + size_ListYmin;
    ListYmax((num_Ymax + 1):(num_Ymax + size_ListYmax)) = ListYmax(1:size_ListYmax) + (count)*(UnitBrickNSpheres);
    num_Ymax = num_Ymax + size_ListYmax;
    
    ListZmin((num_Zmin + 1):(num_Zmin + size_ListZmin)) = ListZmin(1:size_ListZmin) + count*UnitBrickNSpheres;
    num_Zmin = num_Zmin + size_ListZmin;
    ListZmax((num_Zmax + 1):(num_Zmax + size_ListZmax)) = ListZmax(1:size_ListZmax) + (count)*(UnitBrickNSpheres);
    num_Zmax = num_Zmax + size_ListZmax;
    
    
    FinalNSpheres = FinalNSpheres + UnitBrickNSpheres;
end

if (numel(count)==0)
    count=0;
end;    


%Determining which face will be on end of row

if mod(count,2) == 0%Even
    ListXmax = ListXmax + count*UnitBrickNSpheres;
    size_Xmax = num_Xmax;
else %odd
    ListXmax = ListXmin + count*UnitBrickNSpheres;
    num_Xmax = num_Xmin;
    size_Xmax = num_Xmin;
end
size_Xmin = num_Xmin;

size_Ymin = num_Ymin; %size of the brick, will be constant through iterations
size_Ymax = num_Ymax;

size_Zmin = num_Zmin;
size_Zmax = num_Zmax;

%x_max = x_max + x_max*count;

Number2 = FinalNSpheres;

P_even = Positions(:,1:FinalNSpheres);
P_odd = abs([0;y_max;0] - Positions(:,1:FinalNSpheres));



size_Contacts_constant = size_Contacts; %This is the number of contacts in the first brick, every brick will increase the number of contacts by this much

disp('* Unit bricks joined in x direction - done.');

%Start Adding rows
for count = 1: (yBricks-1) %Number of bricks in the y direction
    
    
   if mod(count,2) == 0 %Even
       
       FaceContacts = ListYmin(1:num_Ymin) + (count)*Number2;
       size_FaceContacts = num_Ymin;
       
       Positions(:,(FinalNSpheres + 1):(FinalNSpheres + Number2)) = P_even + (count)*[0;y_max;0];
       
   else %Odd
       FaceContacts = ListYmax(1:num_Ymax) + (count)*Number2;
       size_FaceContacts = num_Ymax;
       
       Positions(:,(FinalNSpheres + 1):(FinalNSpheres + Number2)) = P_odd + (count)*[0;y_max;0];
       
       
   end
   
   
   Contacts((size_Contacts + 1):(size_Contacts + size_FaceContacts),:) = [(FaceContacts - Number2),FaceContacts];
    size_Contacts = size_Contacts + size_FaceContacts;
    
    Contacts((size_Contacts+1):(size_Contacts + size_Contacts_constant),:) = Contacts(1:size_Contacts_constant,:) + (count)*(Number2);
    size_Contacts = size_Contacts + size_Contacts_constant;
   
    ListXmin((num_Xmin + 1):(num_Xmin + size_Xmin)) = ListXmin(1:size_Xmin) + (count)*(Number2);
    num_Xmin = num_Xmin + size_Xmin;
    ListXmax((num_Xmax + 1):(num_Xmax + size_Xmax)) = ListXmax(1:size_Xmax) + (count)*(Number2);
    num_Xmax = num_Xmax + size_Xmax;
    
    ListZmin((num_Zmin + 1):(num_Zmin + size_Zmin)) = ListZmin(1:size_Zmin) + (count)*(Number2);
    num_Zmin = num_Zmin + size_Zmin;
    ListZmax((num_Zmax + 1):(num_Zmax + size_Zmax)) = ListZmax(1:size_Zmax) + (count)*(Number2);
    num_Zmax = num_Zmax + size_Zmax;
    
    Radii((FinalNSpheres+1):(FinalNSpheres+Number2)) = Radii(1:Number2);
        
        
    FinalNSpheres = FinalNSpheres + Number2;
end

if (numel(count)==0)
    count=0;
end;    

if mod(count,2) == 0%Even
   ListYmax = ListYmax + (count)*(Number2);
   size_Ymax = num_Ymax;
else %Odd
    ListYmax = ListYmin + (count)*(Number2);
    num_Ymax = num_Ymin;
    size_Ymax = num_Ymin;
end

%y_max = y_max + y_max*count;

disp('* Unit bricks joined in y direction - done.');

%Start adding layers

size_Xmin = num_Xmin;
size_Xmax= num_Xmax;

size_Ymin = num_Ymin; %size of the brick, will be constant through iterations
size_Ymax = num_Ymax;

size_Zmin = num_Zmin;
size_Zmax = num_Zmax;

Number3 = FinalNSpheres;

P_even = Positions(:,1:FinalNSpheres);
P_odd = abs([0;0;z_max] - Positions(:,1:FinalNSpheres));

size_Contacts_constant = size_Contacts; %This is the number of contacts in the first layer, every layer will increase the number of contacts by this much

for count = 1: (zBricks-1) %Number of Bricks in the z direction
    
    
   if mod(count,2) == 0 %Even
       
       FaceContacts = ListZmin(1:num_Zmin) + (count)*Number3;
       size_FaceContacts = num_Zmin;
       
       Positions(:,(FinalNSpheres + 1):(FinalNSpheres + Number3)) = P_even + (count)*[0;0;z_max];
       
   else %Odd
       FaceContacts = ListZmax(1:num_Zmax) + (count)*Number3;
       size_FaceContacts = num_Zmax;
       
       Positions(:,(FinalNSpheres + 1):(FinalNSpheres + Number3)) = P_odd + (count)*[0;0;z_max];
   end
   
    Contacts((size_Contacts + 1):(size_Contacts + size_FaceContacts),:) = [(FaceContacts - Number3),FaceContacts];
    size_Contacts = size_Contacts + size_FaceContacts;
    
    Contacts((size_Contacts+1):(size_Contacts + size_Contacts_constant),:) = Contacts(1:size_Contacts_constant,:) + (count)*(Number3);
    size_Contacts = size_Contacts + size_Contacts_constant;
   
    ListXmin((num_Xmin + 1):(num_Xmin + size_Xmin)) = ListXmin(1:size_Xmin) + (count)*(Number3);
    num_Xmin = num_Xmin + size_Xmin;
    ListXmax((num_Xmax + 1):(num_Xmax + size_Xmax)) = ListXmax(1:size_Xmax) + (count)*(Number3);
    num_Xmax = num_Xmax + size_Xmax;
    
    ListYmin((num_Ymin + 1):(num_Ymin + size_Ymin)) = ListYmin(1:size_Ymin) + (count)*(Number3);
    num_Ymin = num_Ymin + size_Ymin;
    ListYmax((num_Ymax + 1):(num_Ymax + size_Ymax)) = ListYmax(1:size_Ymax) + (count)*(Number3);
    num_Ymax = num_Ymax + size_Ymax;
    
    Radii((FinalNSpheres+1):(FinalNSpheres+Number3)) = Radii(1:Number3);
        
    FinalNSpheres = FinalNSpheres + Number3;
end

if (numel(count)==0)
    count=0;
end;    

if mod(count,2) == 0%Even
   ListZmax = ListZmax + (count)*(Number3);
   size_Zmax = num_Zmax;
else %Odd
    ListZmax = ListZmin + (count)*(Number3);
    num_Zmax = num_Zmin;
    size_Zmax = num_Zmin;
end

disp('* Unit bricks joined in z direction - done.');



%%
Positions = average*Positions; %Rescaling the position and radii of spheres
Radii = average*Radii;

disp('--- Total volume generation complete ---');

disp('--- All done! ---');
end

