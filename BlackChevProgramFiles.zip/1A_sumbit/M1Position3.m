function [F] = Position3(x,P1,P2,P3,R1,R2,R3,r_new)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
F = [norm(x - P1) - (r_new + R1);
     norm(x - P2) - (r_new + R2);
     norm(x - P3) - (r_new + R3)];
end

