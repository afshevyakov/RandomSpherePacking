function [NEXT,N,R,P,Parents,num_P,Contacts,size_Contacts,P3,size_P3] = Search2D(p_new,r_new,P,R,N,Parents,num_P,Contacts,size_Contacts,P3,size_P3,count,x_max,y_max,z_max,r_max,epsilon,delta)
%UNTITLED Summary of this function goes here
%   Parents(count,:) is the indicies of parents that spawned p_new.

NEXT = false;

PP = uint32(zeros(100,2)); %PossibleParents
PC = uint32(zeros(100,2)); %Possible Contacts
beta = uint32(zeros(100,1));

size_PP = uint32(0);
size_PC = uint32(0);
size_beta = uint32(0);


if  ((p_new(1) - r_new) < 0)||((p_new(1) + r_new) > x_max)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new) > y_max)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new) > z_max)%Overlap with Boundary
    NEXT = true;
else %Not in contact with boundary, need to check particles.
    
    TEST_norm = vecnorm(P(:,1:N) - p_new);
    INDEX = find(TEST_norm < r_new + r_max); %Find the index of all paricles that are possible contacts
    
    for count2 = 1:size(INDEX,2) %INDEX should be 1xM so want 2nd dimension
        if NEXT == true
            break
        end
        
        index = INDEX(count2);
        
        if norm(P(:,index) - p_new) < R(index) + r_new - epsilon %Particle overlap
            
            NEXT = true;
            
        elseif norm(P(:,index) - p_new) < R(index) + r_new + epsilon %p_new in contact and parent with index
            
            size_PP = size_PP + 1;
            PP(size_PP,:) = [index, N+1]; %N hasnt changed yet, so need to add one to account for this
            
            size_PC = size_PC + 1;
            PC(size_PC,:) = [index, N+1];
            
            size_beta = size_beta + 1;
            beta(size_beta) = index;
            
        elseif norm(P(:,index) - p_new) < R(index) + r_new + delta %p_new in parent with index
            
            size_PP = size_PP + 1;
            PP(size_PP,:) = [index, N+1]; %N hasnt changed yet, so need to add one to account for this
            
            size_beta = size_beta + 1;
            beta(size_beta) = index;
            
        end
    end
end

%The Particle check should include original parents

if NEXT == false %No border or particle overlap
    
    Parents(count,:) = []; %Remove parents that spawned p_new
    num_P = num_P - 1; %Accounting for the removed parents
    
    N = N+1;
    P(:,N) = p_new;
    R(N) = r_new;
    size_beta;
    Beta = sort(beta,'descend'); %beta list ordered from smallest to largest, so index of count3 < count4
    for count3 = 1:(size_beta - 1)
        for count4 = (count3 + 1):size_beta
            
            part_A = Beta(count4);
            part_B = Beta(count3); %part_A < part_B
            
            if norm(P(:,part_A) - P(:,part_B)) < R(part_A) + R(part_B) + delta
                size_P3 = size_P3 + 1; %Adding another triplet to list of 3d parents
                P3(size_P3,:) = [part_A, part_B, N]; %Form triplet with N(new particle)
            end
            
        end
    end
    
    Contacts((size_Contacts + 1):(size_Contacts + size_PC),:) = PC(1:size_PC,:);
    size_Contacts = size_Contacts + size_PC;
    
    Parents((num_P + 1):(num_P + size_PP),:) = PP(1:size_PP,:);
    num_P = num_P + size_PP;
    
    
end

%If NeXT = true will return that, and also everyting will be the
%same as the input, no added parents or contacts






end %End of function

