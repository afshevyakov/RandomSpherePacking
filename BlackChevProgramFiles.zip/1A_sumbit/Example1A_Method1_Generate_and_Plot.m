%% Matlab script for Example 1A: Method 1, using Weibull distribution
% Produces the sphere filling of the domain V and plots of Figure 2 (a, c, e) and figures similar to Fig.3 (a,b) 
% Required files:
% * Method1GenerateSpheres.m -- main sphere filling routine
% * Auxiliary routine files for Method1GenerateSpheres.m :
%    - M1Position2Xmax.m
%    - M1Position2Xmin.m
%    - M1Position2Ymax.m
%    - M1Position2Ymin.m
%    - M1Position2Zmax.m
%    - M1Position2Zmin.m
%    - M1Position3.m
%    - M1Search2D.m
%    - M1Search3D.m

clear all; close all; clc;

%% Sphere Packing parameters: Weibull distribution

% -- use Weibull distribution implemented in Matlab
% with parameters from Steuben, Iliopoulos, Michopoulos (2016)

rng(0); %random seed zero: Matlab default
Weibull_scale = 31.4/2; % scale parameter lambda for the radius in Weibull distribution; in micrometers. The scale parameter for *diameter* is 31.4.
Weibull_shape = 3.55; % shape parameter k in Weibull distribution; dimensionless

ProbabilityDistribution = makedist('Weibull','a',Weibull_scale ,'b', Weibull_shape);

average_radius = mean(ProbabilityDistribution);
FaceGoal = 0.8;  % desired sphere/face area fraction; recommended for Method 1: 0.8
BodyGoal = 0.55; % desired sphere/volume fraction; recommended for Method 1: 0.55

%Unit brick: here unit cube
std_length = 15*average_radius; 
BrickSideLengths = [1;1;1]* std_length;

%numbers of cubes in x, y, z directions to fill the total domain V
BrickNumbers = [2;2;1];

SphereContactParameter = 0.2; %This is the contact parameter, within [0,1]. If particles are within SphereContactParameter*average_radius of each other, they are considered to be in contact
ParentParameter = 0.5; %This is the parent parameter, within [0,1]. If particles are within ParentParameter*average_radius of each other, they are considered to be potential parents

%% Run the sphere generation Method 1 algorithm and save results.

tic;
[FinalNSpheres, UnitBrickNSpheres, Positions, Radii, Contacts, ListXmin, ListYmin, ListZmin, ListXmax, ListYmax, ListZmax] = ...
  Method1GenerateSpheres( ...
    ProbabilityDistribution, ...
    FaceGoal, BodyGoal, ...
    SphereContactParameter, ParentParameter, ...
    BrickSideLengths, BrickNumbers );

sphere_filling_total_time = toc

%Save computations 
save('Example1A_Method1_Results.mat')

%% Now some plots: reproduce Fig. 

[x_sph, y_sph, z_sph] = sphere;

%% Unit Cube Plot
figure(11)
hold on
axis equal
percent = 0;
List = 1:UnitBrickNSpheres; %particles you want to display
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
    
    if mod(count,1000)==0
        percent = 100*(count/UnitBrickNSpheres); %Keeping track of progress
        disp(['Plotting Unit Cube ',num2str(percent), '% complete'])
    end
    
end
xlim([0, BrickSideLengths(1)]);
ylim([0, BrickSideLengths(1)]);
zlim([0, BrickSideLengths(1)]);
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view(60, 45);
hold off;

% Save figure - uncomment as needed
% savefig('Example1A_Method1_UnitCube.fig');
% print('Example1A_Method1_UnitCube','-dpdf');

%% Unit Cube Middle Third
figure(13)
hold on
axis equal
List = find((Positions(3,1:UnitBrickNSpheres) > (1/3)*BrickSideLengths(1)) & (Positions(3,1:UnitBrickNSpheres) < (2/3)*BrickSideLengths(1))); %Selecting all spheres in middle third of cube
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
    
    if mod(count,1000)==0
        percent = 100*(count/size(List,2)); %Keeping track of progress
        disp(['Plotting middle third of Unit Cube ',num2str(percent), '% complete'])
    end
end
xlim([0, BrickSideLengths(1)]);
ylim([0, BrickSideLengths(1)]);
zlim([0, BrickSideLengths(1)]);
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view(60, 45);
hold off;

% Save figure - uncomment as needed
% savefig('Example1A_Method1_UnitCube_Middle.fig');
% print('Example1A_Method1_UnitCube_Middle','-dpdf');

%% Plot theoretical vs. actual distribution
FF=figure(14);
hold on
%plot histogram of obtained radii
histogram(Radii,30,'Normalization','pdf');

%plot Weibull PDF 
Weibull_scale = 31.4/2; % scale parameter lambda in Weibull distribution; in micrometers
Weibull_shape = 3.55; % shape parameter k in Weibull distribution; dimensionless
ProbabilityDistribution = makedist('Weibull','a',Weibull_scale ,'b', Weibull_shape);
X = linspace(0,max(Radii)*1.1);
Y = pdf(ProbabilityDistribution,X);
plot(X,Y, 'LineWidth', 3);
set(gca, 'FontSize', 14)
xlabel('Particle radius ($\mu$m)','Interpreter','latex')
ylabel('Probability density','Interpreter','latex')
legend('Actual', 'Weibull', 'Interpreter','latex', 'location', 'northeast')
xlim([0, max(Radii)*1.1]);
hold off

% Save figure - uncomment as needed
% savefig('Example1A_Method1_UnitCube_DistributionCurves.fig');
% print('Example1A_Method1_UnitCube_DistributionCurves','-dpdf');

%% Two Cubes joined to make a 2x1 brick
figure(21)
hold on
axis equal

%1:Number will be the spheres in the first unit cube, N is the total number
%of spheres, all cubes combined.
List = 1:2*UnitBrickNSpheres;% 
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
    
    if mod(count,1000)==0
        percent = 100*(count/(2*UnitBrickNSpheres)); %Keeping track of progress
        disp(['Plotting 2 Cubes Joined ',num2str(percent), '% complete'])
    end
end
xlim([0, 2*BrickSideLengths(1)])
ylim([0, BrickSideLengths(1)])
zlim([0, BrickSideLengths(1)])
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');

%Overhead View
view(0,90);
hold off;

% Save figure - uncomment as needed
% savefig('Example1A_Method1_Overhead.fig');
% print('Example1A_Method1_TwoCubes_Overhead','-dpdf');


%% Total Build (in this example, it is 2x2 unit cubes)
figure(23)
hold on
axis equal

List = 1:FinalNSpheres;
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
    
    if mod(count,1000)==0
        percent = 100*(count/FinalNSpheres); %Keeping track of progress
        disp(['Plotting total build ',num2str(percent), '% complete'])
    end
end
xlim([0, 2*BrickSideLengths(1)])
ylim([0, 2*BrickSideLengths(1)])
zlim([0, BrickSideLengths(1)])
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view(60, 30);
hold off;

% Save figure - uncomment as needed
% savefig('Example1A_Method1_TotalBuild.fig');
% print('Example1A_Method1_TotalBuild','-dpdf');
