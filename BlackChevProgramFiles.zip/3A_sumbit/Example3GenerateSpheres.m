function [NSpheres, Positions, Radii, Contacts] = Example3GenerateSpheres(...
    ProbabilityDistr, ...
    BrickSideLengths, ...
    HemisphereRadii, ...
    FaceGoal, BodyGoal, ...
    SphereContactParameter ...
    )

output_percent_step=10;

% the computation is dimensionless

% average = scale*gamma(1+ (1/shape)); %Mean is for radius
average = mean(ProbabilityDistr);

% epsilon = 0.1;
% delta = 0.5;

epsilon = SphereContactParameter;
%delta = ParentParameter; % not needed

x_min = 0;
x_max = BrickSideLengths(1)/average; %The input was given in terms of actual sphere size, however the function places spheres with average size of 1, so parameters need to be scaled to match "unit distribution"
y_min = 0;
y_max = BrickSideLengths(2)/average;
z_min = 0;
z_max = BrickSideLengths(3)/average;



GoalForZ = x_max*y_max*FaceGoal;
GoalForY = x_max*z_max*FaceGoal;

SC1 = [0; y_max/2; z_max/2]; %Sphere Center of Spherical boundary 1
SC2 = [x_max; y_max/2; z_max/2]; %Sphere Center of Spherical boundary 2

R1 = HemisphereRadii(1)/average; %Radius of Sphere boundary1    %The input was given in terms of actual sphere size, however the function places spheres with average size of 1, so parameters need to be scaled to match "unit distribution"
R2 = HemisphereRadii(2)/average; %Radius of Sphere Boundary 2

%Will need to scale up position and radius of spheres to match desired
%distribution, since function places spheres from "unit distribution" with
%average radius of 1
Radii = zeros(1,100); %Setting empty radius array
Positions = zeros(3,100); %Setting blank position array

ParentsZmin = false(100);
ParentsZmax = false(100);
ParentsYmin = false(100);
ParentsYmax = false(100);
Parents3 = false(100,100,100);

Radii(1:8) = 1; %Setting initial radii

Positions(:,1) = [(x_max/2)-1; y_max/2; 1];
Positions(:,2) = [(x_max/2)+1; y_max/2; 1]; %Parents on Zmin
ParentsZmin(1,2) = true;
num_Zmin = 2;
area_Zmin = 4*pi; %Area of the four initial spheres projected onto the Zmin face

Positions(:,3) = [(x_max/2)-1; y_max/2;(z_max - 1)];
Positions(:,4) = [(x_max/2)+1; y_max/2;(z_max - 1)]; %Parents on Zmax
ParentsZmax(3,4) = true;
num_Zmax = 2;
area_Zmax = 4*pi; %Area of the four initial spheres projected onto the Zmax face

Positions(:,5) = [x_max/2; 1; (z_max/2)-1];
Positions(:,6) = [x_max/2; 1; (z_max/2)+1]; %Parents on Ymin
ParentsYmin(5,6) = true;
num_Ymin = 2;
area_Ymin = 4*pi; %Area of the four initial spheres projected onto the Ymin face

Positions(:,7) = [x_max/2;(y_max-1);(z_max/2)-1];
Positions(:,8) = [x_max/2;(y_max-1);(z_max/2)+1]; %Parents on Ymax
ParentsYmax(7,8) = true;
num_Ymax = 2;
area_Ymax = 4*pi; %Area of the four initial spheres projected onto the Ymax face

NSpheres = 8;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('--- Starting sphere filling of the specified domain: Example 3 ---');
disp('* Probability distribution and its parameters:');
disp(ProbabilityDistr);
fprintf('* Average sphere radius: %2.5f [physical units]\n', average);
fprintf('* Dimensions of the brick for the domain: [same physical units]: %2.5f x %2.5f x %2.5f\n', BrickSideLengths(1), BrickSideLengths(2), BrickSideLengths(3));
fprintf('* Hemisphere on the face x=0 radius: %2.5f [physical units]\n', HemisphereRadii(1));
fprintf('* Hemisphere on the face x=x_max radius: %2.5f [physical units]\n', HemisphereRadii(2));
fprintf('* Face goal: %2.5f%% of faces to be covered with spheres\n', FaceGoal*100);
fprintf('* Body goal: %2.5f%% of volume to be occupied with spheres\n', BodyGoal*100);
fprintf('* Sphere contact parameter: %2.5f \n', SphereContactParameter);

disp('--- Filling the domain faces ... ---');

%% Placement on Zmin
r_new = (1/average)*random(ProbabilityDistr);
FAIL = 0;
perc = 0;
prev_percent=0;

while area_Zmin < GoalForZ
    [I, J] = find(ParentsZmin == true);
    A = [I, J];
    
    for count = 1:size(A,1) %number of pairs in A
        i = A(count,1); j = A(count,2); %Giving indicies of pair
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;0;1]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) EG3Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new)>y_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
            
            fun = @(x) EG3Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new > y_max))||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                FAIL = FAIL + 1;
            else %Doens't intersect boundary, need to check with other paritlces
                part = 1; NEXT = false;
                while (part <= NSpheres)&&(NEXT == false)
                    if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                        NEXT = true;
                    end
                    part = part + 1;
                end
                
                if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                    FAIL = FAIL + 1;
                else %Works in second spot
                    
                    NSpheres = NSpheres+1;
                    Radii(NSpheres) = r_new;
                    Positions(:,NSpheres) = p_new;
                    num_Zmin = num_Zmin + 1;
                    area_Zmin = area_Zmin + pi*r_new*r_new; %Projected area of spheres onto Zmin increases by the projected area of the newly placed sphere
                    r_new = (1/average)*random(ProbabilityDistr);
                    ParentsZmin(i,j) = false; %Since they had a child they are no longer viable parents
                    ParentsZmin(i,NSpheres) = true;
                    ParentsZmin(j,NSpheres) = true;
                    Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                end
                
            end
        else %Doesn't overlap boundary, need to check with other particles
            part = 1; NEXT = false;
            while (part <= NSpheres)&&(NEXT == false)
                if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                    NEXT = true;
                end
                part = part + 1;
            end
            
            if NEXT == true %Overlaps with other particles, Need to try second spot
                
                
                
                x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
                
                fun = @(x) EG3Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
                options = optimoptions('fsolve','Display','none');
                p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
                
                if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new)>y_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                    FAIL = FAIL + 1;
                else %Doens't intersect boundary, need to check with other paritlces
                    part = 1; NEXT = false;
                    while (part <= NSpheres)&&(NEXT == false)
                        if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                            NEXT = true;
                        end
                        part = part + 1;
                    end
                    
                    if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                        FAIL = FAIL + 1;
                    else %Works in second spot
                        
                        NSpheres = NSpheres+1;
                        Radii(NSpheres) = r_new;
                        Positions(:,NSpheres) = p_new;
                        num_Zmin = num_Zmin + 1;
                        area_Zmin = area_Zmin + pi*r_new*r_new; %Projected area of spheres onto Zmin increases by the projected area of the newly placed sphere
                        r_new = (1/average)*random(ProbabilityDistr);
                        ParentsZmin(i,j) = false; %Since they had a child they are no longer viable parents
                        ParentsZmin(i,NSpheres) = true;
                        ParentsZmin(j,NSpheres) = true;
                        Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                    end
                    
                end
                
            else %Works in first spot
                
                NSpheres = NSpheres+1;
                Radii(NSpheres) = r_new;
                Positions(:,NSpheres) = p_new;
                num_Zmin = num_Zmin + 1;
                area_Zmin = area_Zmin + pi*r_new*r_new; %Projected area of spheres onto Zmin increases by the projected area of the newly placed sphere
                r_new = (1/average)*random(ProbabilityDistr);
                ParentsZmin(i,j) = false; %Since they had a child they are no longer viable parents
                ParentsZmin(i,NSpheres) = true;
                ParentsZmin(j,NSpheres) = true;
                Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
            end
        end
        if FAIL > size(A,1) %Tried every viable parent
            FAIL = 0;
            r_new = (1/average)*random(ProbabilityDistr);%grab mew sphere
        end
    end
    perc = area_Zmin/GoalForZ*100;
    percent = round( min( [100, perc]) );

    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the z-min face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
end



%% Placement on Zmax

r_new = (1/average)*random(ProbabilityDistr);
FAIL = 0;
perc = 0;
prev_percent=0;

while area_Zmax < GoalForZ
    [I, J] = find(ParentsZmax == true);
    A = [I, J];
    
    for count = 1:size(A,1) %number of pairs in A
        i = A(count,1); j = A(count,2); %Giving indicies of pair
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;0;1]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) EG3Position2Zmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,z_max);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new)>y_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
            
            fun = @(x) EG3Position2Zmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,z_max);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new > y_max))||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                FAIL = FAIL + 1;
            else %Doens't intersect boundary, need to check with other paritlces
                part = 1; NEXT = false;
                while (part <= NSpheres)&&(NEXT == false)
                    if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                        NEXT = true;
                    end
                    part = part + 1;
                end
                
                if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                    FAIL = FAIL + 1;
                else %Works in second spot
                    
                    NSpheres = NSpheres+1;
                    Radii(NSpheres) = r_new;
                    Positions(:,NSpheres) = p_new;
                    num_Zmax = num_Zmax + 1;
                    area_Zmax = area_Zmax + pi*r_new*r_new; %Projected area of spheres onto Zmax increases by the projected area of the newly placed sphere
                    r_new = (1/average)*random(ProbabilityDistr);
                    ParentsZmax(i,j) = false; %Since they had a child they are no longer viable parents
                    ParentsZmax(i,NSpheres) = true;
                    ParentsZmax(j,NSpheres) = true;
                    Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                end
                
            end
        else %Doesn't overlap boundary, need to check with other particles
            part = 1; NEXT = false;
            while (part <= NSpheres)&&(NEXT == false)
                if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                    NEXT = true;
                end
                part = part + 1;
            end
            
            if NEXT == true %Overlaps with other particles, Need to try second spot
                
                
                
                x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
                
                fun = @(x) EG3Position2Zmax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,z_max);
                options = optimoptions('fsolve','Display','none');
                p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
                
                if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(2) - r_new) < 0)||((p_new(2) + r_new)>y_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                    FAIL = FAIL + 1;
                else %Doens't intersect boundary, need to check with other paritlces
                    part = 1; NEXT = false;
                    while (part <= NSpheres)&&(NEXT == false)
                        if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                            NEXT = true;
                        end
                        part = part + 1;
                    end
                    
                    if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                        FAIL = FAIL + 1;
                    else %Works in second spot
                        
                        NSpheres = NSpheres+1;
                        Radii(NSpheres) = r_new;
                        Positions(:,NSpheres) = p_new;
                        num_Zmax = num_Zmax + 1;
                        area_Zmax = area_Zmax + pi*r_new*r_new; %Projected area of spheres onto Zmax increases by the projected area of the newly placed sphere
                        r_new = (1/average)*random(ProbabilityDistr);
                        ParentsZmax(i,j) = false; %Since they had a child they are no longer viable parents
                        ParentsZmax(i,NSpheres) = true;
                        ParentsZmax(j,NSpheres) = true;
                        Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                    end
                    
                end
                
                
                
            else %Works in first spot
                
                NSpheres = NSpheres+1;
                Radii(NSpheres) = r_new;
                Positions(:,NSpheres) = p_new;
                num_Zmax = num_Zmax + 1;
                area_Zmax = area_Zmax + pi*r_new*r_new; %Projected area of spheres onto Zmax increases by the projected area of the newly placed sphere
                r_new = (1/average)*random(ProbabilityDistr);
                ParentsZmax(i,j) = false; %Since they had a child they are no longer viable parents
                ParentsZmax(i,NSpheres) = true;
                ParentsZmax(j,NSpheres) = true;
                Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
            end
        end
        if FAIL > size(A,1) %Tried every viable parent
            FAIL = 0;
            r_new = (1/average)*random(ProbabilityDistr);
        end
    end
    
    perc = area_Zmax/GoalForZ*100;
    percent = round( min( [100, perc]) );

    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the z-max face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end



%% Placement on Ymin
r_new = (1/average)*random(ProbabilityDistr);
FAIL = 0;
perc = 0;
prev_percent=0;

while area_Ymin < GoalForY
    [I, J] = find(ParentsYmin == true);
    A = [I, J];
    
    for count = 1:size(A,1) %number of pairs in A
        i = A(count,1); j = A(count,2); %Giving indicies of pair
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;1;0]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) EG3Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
            
            fun = @(x) EG3Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new > z_max))||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                FAIL = FAIL + 1;
            else %Doens't intersect boundary, need to check with other paritlces
                part = 1; NEXT = false;
                while (part <= NSpheres)&&(NEXT == false)
                    if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                        NEXT = true;
                    end
                    part = part + 1;
                end
                
                if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                    FAIL = FAIL + 1;
                else %Works in second spot
                    
                    NSpheres = NSpheres+1;
                    Radii(NSpheres) = r_new;
                    Positions(:,NSpheres) = p_new;
                    num_Ymin = num_Ymin + 1;
                    area_Ymin = area_Ymin + pi*r_new*r_new; %Projected area of spheres onto Ymin increases by the projected area of the newly placed sphere
                    r_new = (1/average)*random(ProbabilityDistr);
                    ParentsYmin(i,j) = false; %Since they had a child they are no longer viable parents
                    ParentsYmin(i,NSpheres) = true;
                    ParentsYmin(j,NSpheres) = true;
                    Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                end
                
            end
        else %Doesn't overlap boundary, need to check with other particles
            part = 1; NEXT = false;
            while (part <= NSpheres)&&(NEXT == false)
                if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                    NEXT = true;
                end
                part = part + 1;
            end
            
            if NEXT == true %Overlaps with other particles, Need to try second spot
                
                
                
                x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
                
                fun = @(x) EG3Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
                options = optimoptions('fsolve','Display','none');
                p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
                
                if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                    FAIL = FAIL + 1;
                else %Doens't intersect boundary, need to check with other paritlces
                    part = 1; NEXT = false;
                    while (part <= NSpheres)&&(NEXT == false)
                        if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                            NEXT = true;
                        end
                        part = part + 1;
                    end
                    
                    if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                        FAIL = FAIL + 1;
                    else %Works in second spot
                        
                        NSpheres = NSpheres+1;
                        Radii(NSpheres) = r_new;
                        Positions(:,NSpheres) = p_new;
                        num_Ymin = num_Ymin + 1;
                        area_Ymin = area_Ymin + pi*r_new*r_new; %Projected area of spheres onto Ymin increases by the projected area of the newly placed sphere
                        r_new = (1/average)*random(ProbabilityDistr);
                        ParentsYmin(i,j) = false; %Since they had a child they are no longer viable parents
                        ParentsYmin(i,NSpheres) = true;
                        ParentsYmin(j,NSpheres) = true;
                        Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                    end
                    
                end
                
                
                
            else %Works in first spot
                
                NSpheres = NSpheres+1;
                Radii(NSpheres) = r_new;
                Positions(:,NSpheres) = p_new;
                num_Ymin = num_Ymin + 1;
                area_Ymin = area_Ymin + pi*r_new*r_new; %Projected area of spheres onto Ymin increases by the projected area of the newly placed sphere
                r_new = (1/average)*random(ProbabilityDistr);
                ParentsYmin(i,j) = false; %Since they had a child they are no longer viable parents
                ParentsYmin(i,NSpheres) = true;
                ParentsYmin(j,NSpheres) = true;
                Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
            end
        end
        if FAIL > size(A,1) %Tried every viable parent
            FAIL = 0;
            r_new = (1/average)*random(ProbabilityDistr);
        end
    end
    
    perc = area_Ymin/GoalForY*100;
    percent = round( min( [100, perc]) );

    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the y-min face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end



%% Placement on Ymax
r_new = (1/average)*random(ProbabilityDistr);
FAIL = 0;
perc = 0;
prev_percent=0;

while area_Ymax < GoalForY
    [I, J] = find(ParentsYmax == true);
    A = [I, J];
    
    for count = 1:size(A,1) %number of pairs in A
        i = A(count,1); j = A(count,2); %Giving indicies of pair
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;1;0]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) EG3Position2Ymax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,y_max);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
            
            fun = @(x) EG3Position2Ymax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,y_max);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new > z_max))||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                FAIL = FAIL + 1;
            else %Doens't intersect boundary, need to check with other paritlces
                part = 1; NEXT = false;
                while (part <= NSpheres)&&(NEXT == false)
                    if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                        NEXT = true;
                    end
                    part = part + 1;
                end
                
                if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                    FAIL = FAIL + 1;
                else %Works in second spot
                    
                    NSpheres = NSpheres+1;
                    Radii(NSpheres) = r_new;
                    Positions(:,NSpheres) = p_new;
                    num_Ymax = num_Ymax + 1;
                    area_Ymax = area_Ymax + pi*r_new*r_new; %Projected area of spheres onto Ymax increases by the projected area of the newly placed sphere
                    r_new = (1/average)*random(ProbabilityDistr);
                    ParentsYmax(i,j) = false; %Since they had a child they are no longer viable parents
                    ParentsYmax(i,NSpheres) = true;
                    ParentsYmax(j,NSpheres) = true;
                    Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                end
                
            end
        else %Doesn't overlap boundary, need to check with other particles
            part = 1; NEXT = false;
            while (part <= NSpheres)&&(NEXT == false)
                if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                    NEXT = true;
                end
                part = part + 1;
            end
            
            if NEXT == true %Overlaps with other particles, Need to try second spot
                
                
                
                x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat);
                
                fun = @(x) EG3Position2Ymax(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new,y_max);
                options = optimoptions('fsolve','Display','none');
                p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
                
                if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max) %p_new overlaps with boundary
                    FAIL = FAIL + 1;
                else %Doens't intersect boundary, need to check with other paritlces
                    part = 1; NEXT = false;
                    while (part <= NSpheres)&&(NEXT == false)
                        if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                            NEXT = true;
                        end
                        part = part + 1;
                    end
                    
                    if NEXT == true %Overlaps with other particles, since it won't fit in second potition, wont fit with these parents
                        FAIL = FAIL + 1;
                    else %Works in second spot
                        
                        NSpheres = NSpheres+1;
                        Radii(NSpheres) = r_new;
                        Positions(:,NSpheres) = p_new;
                        num_Ymax = num_Ymax + 1;
                        area_Ymax = area_Ymax + pi*r_new*r_new; %Projected area of spheres onto Ymax increases by the projected area of the newly placed sphere
                        r_new = (1/average)*random(ProbabilityDistr);
                        ParentsYmax(i,j) = false; %Since they had a child they are no longer viable parents
                        ParentsYmax(i,NSpheres) = true;
                        ParentsYmax(j,NSpheres) = true;
                        Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
                    end
                    
                end
                
                
                
            else %Works in first spot
                
                NSpheres = NSpheres+1;
                Radii(NSpheres) = r_new;
                Positions(:,NSpheres) = p_new;
                num_Ymax = num_Ymax + 1;
                area_Ymax = area_Ymax + pi*r_new*r_new; %Projected area of spheres onto Ymax increases by the projected area of the newly placed sphere
                r_new = (1/average)*random(ProbabilityDistr);
                ParentsYmax(i,j) = false; %Since they had a child they are no longer viable parents
                ParentsYmax(i,NSpheres) = true;
                ParentsYmax(j,NSpheres) = true;
                Parents3(i,j,NSpheres) = true; %This triple forms parents for 3d growth
            end
        end
        if FAIL > size(A,1) %Tried every viable parent
            FAIL = 0;
            r_new = (1/average)*random(ProbabilityDistr);
        end
    end
    
    perc = area_Ymax/GoalForY*100;
    percent = round( min( [100, perc]) );

    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the y-max face ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end

disp('--- Face generation complete ---');



%% Filling Volume of Cube


disp('--- Filling the domain volume ... ---');

TotalVolume = x_max*y_max*z_max - (1/2)*(4*pi/3)*(R1^3) - (1/2)*(4*pi/3)*(R2^3); %Volume of cube minus volume of Spherical Boundaries, might become problematic if the spherical boundaries are larger than the cube
V = (4*pi/3)*(Radii.^3); %Volume of all placed spheres
SphereVolume = sum(V);

prev_percent=0;

while (SphereVolume)/(TotalVolume) < BodyGoal
    %PP3 is updated at beginning of each loop, Parents3 added during loop
    %are not added to PP3 until beginning of next loop
    [PP3_1, PP3_2, PP3_3] = ind2sub(size(Parents3), find(Parents3 == true)); %PP3 has the indicies of all possible parents
    PP3 = [PP3_1, PP3_2, PP3_3];
    
    for count = 1:size(PP3,1)
        I = PP3(count,1); J = PP3(count,2); K = PP3(count,3);
        
        %Determining x_0
        Centeroid = [(Positions(1,I) + Positions(1,J) + Positions(1,K))/3; (Positions(2,I) + Positions(2,J) + Positions(2,K))/3; (Positions(3,I) + Positions(3,J) + Positions(3,K))/3;];
        P_ij = (Positions(:,J) - Positions(:,I))/norm(Positions(:,J) - Positions(:,I));
        P_ik = (Positions(:,K) - Positions(:,I))/norm(Positions(:,K) - Positions(:,I));
        t_hat = cross(P_ij, P_ik);
        
        x_0 = Centeroid + (r_new)*(t_hat);
        
        fun = @(x) EG3Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        
        if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max)||((p_new(2) - r_new)<0)||((p_new(2) + r_new) > y_max)%Border Overlap in first position
            x_0 = Centeroid + (r_new)*(-t_hat);
            
            fun = @(x) EG3Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max)||((p_new(2) - r_new)<0)||((p_new(2) + r_new) > y_max)%Border overlap in 2nd position, will not fit
                FAIL = FAIL + 1;
            else %No border overlap in 2nd position, need to check particles
                part = 1; NEXT = false;
                while (part <= NSpheres)&&(NEXT == false)
                    if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                        NEXT = true;
                    end
                    part = part + 1;
                end
                
                if NEXT == true %Overlaps with partices in 2nd position will not fit
                    FAIL = FAIL + 1;
                else %Does not overlap with particles, fits in 2nd spot
                    NSpheres = NSpheres+1;
                    Radii(NSpheres) = r_new;
                    Positions(:,NSpheres) = p_new;
                    r_new = (1/average)*random(ProbabilityDistr);
                    SphereVolume = SphereVolume + (4*pi/3)*((Radii(NSpheres))^3);
                    Parents3(I,J,K) = false;
                    Parents3(I,J,NSpheres) = true;
                    Parents3(I,K,NSpheres) = true;
                    Parents3(J,K,NSpheres) = true;
                    
                end
            end
            
        else %No border overlap in 1st position
            part = 1; NEXT = false;
            while (part <= NSpheres)&&(NEXT == false)
                if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                    NEXT = true;
                end
                part = part + 1;
            end
            
            if NEXT == true %Overlaps with partices in 1st, need to try 2nd spot
                
                
                
                x_0 = Centeroid + (r_new)*(-t_hat);
                
                fun = @(x) EG3Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
                options = optimoptions('fsolve','Display','none');
                p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
                
                if (norm(p_new - SC1) < R1 + r_new)||(norm(p_new - SC2) < R2 + r_new)||((p_new(3) - r_new) < 0)||((p_new(3) + r_new)>z_max)||((p_new(1) - r_new)<0)||((p_new(1) + r_new)>x_max)||((p_new(2) - r_new)<0)||((p_new(2) + r_new) > y_max)%Border overlap in 2nd position, will not fit
                    FAIL = FAIL + 1;
                else %No border overlap in 2nd position, need to check particles
                    part = 1; NEXT = false;
                    while (part <= NSpheres)&&(NEXT == false)
                        if norm(p_new - Positions(:,part)) < r_new + Radii(part)
                            NEXT = true;
                        end
                        part = part + 1;
                    end
                    
                    if NEXT == true %Overlaps with partices in 2nd position will not fit
                        FAIL = FAIL + 1;
                    else %Does not overlap with particles, fits in 2nd spot
                        NSpheres = NSpheres+1;
                        Radii(NSpheres) = r_new;
                        Positions(:,NSpheres) = p_new;
                        r_new = (1/average)*random(ProbabilityDistr);
                        SphereVolume = SphereVolume + (4*pi/3)*((Radii(NSpheres))^3);
                        Parents3(I,J,K) = false;
                        Parents3(I,J,NSpheres) = true;
                        Parents3(I,K,NSpheres) = true;
                        Parents3(J,K,NSpheres) = true;
                        
                    end
                end
                
            else %Does not overlap with particles, fits in 1nd spot
                NSpheres = NSpheres+1;
                Radii(NSpheres) = r_new;
                Positions(:,NSpheres) = p_new;
                r_new = (1/average)*random(ProbabilityDistr);
                SphereVolume = SphereVolume + (4*pi/3)*((Radii(NSpheres))^3);
                Parents3(I,J,K) = false;
                Parents3(I,J,NSpheres) = true;
                Parents3(I,K,NSpheres) = true;
                Parents3(J,K,NSpheres) = true;
                
                
            end
        end

        
        if FAIL > (size(PP3,1)/2) %Tried half of the parents
            r_new = (1/average)*random(ProbabilityDistr);
            FAIL = 0;
        end
    end
    
    ratio = SphereVolume/TotalVolume;
    perc = ratio/BodyGoal*100;
    percent = round( min( [100, perc]) );

    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres in the domain bulk ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
        
end


%% Contacts2

Contacts = int32(zeros(NSpheres,2));
size_Contacts = 0;
for count = 1:NSpheres
    
    part = count;
    
    TEST = vecnorm(Positions(:,part) - Positions) - Radii;
    index = find((TEST > -Radii(part))&(TEST < Radii(part) + epsilon)); %All particles within epsilon of part
    
    for count2 = 1:size(index,2) %setting all indecies from idex to true
        i = index(count2);
        
        pair = sort([part,i]); 
        size_Contacts = size_Contacts + 1;
        Contacts(size_Contacts,:) = pair;
    end
    
    
end
Contacts = unique(Contacts,'rows');

Positions = average*Positions; %Rescaling the position and radii of spheres
Radii = average*Radii;

disp('--- Volume generation complete ---');

disp('--- Finished! ---');


end





