%% Matlab script for Example 3: a brick (here cube) with partially spherical noundary

clear all; close all; clc;

% -- use Weibull distribution implemented in Matlab
% with parameters from Steuben, Iliopoulos, Michopoulos (2016)

rng(0); %random seed zero: Matlab default

Weibull_scale = 31.4/2; % scale parameter lambda for the radius in Weibull distribution; in micrometers. The scale parameter for *diameter* is 31.4.
Weibull_shape = 3.55; % shape parameter k in Weibull distribution; dimensionless

ProbabilityDistribution = makedist('Weibull','a',Weibull_scale ,'b', Weibull_shape);

average_radius = mean(ProbabilityDistribution);

FaceGoal = 0.4; 
BodyGoal = 0.4; 

% Unit brick: here a unit cube
std_length = 30*average_radius; 
BrickSideLengths = [1;1;1] * std_length;

% Radii of hemispheres defining the romain, located on x_min and x_max faces
% Recommended: (x-length of the domain)/2 or smaller
HemisphereRadii = [0.5; 0.5] * std_length;

SphereContactParameter = 0.1; 

tic;

[NSpheres, Positions, Radii, Contacts] = ...
  Example3GenerateSpheres( ...
    ProbabilityDistribution, ...
    BrickSideLengths, ...
    HemisphereRadii, ...
    FaceGoal, BodyGoal, ...
    SphereContactParameter ...
 );

sphere_filling_total_time = toc

%% Save all data 
save('Example3A_Cube_Hemisph_data.mat')

%% Plot the given Weibull disribution vs. the actual distribution
figure(1)
hold on
X = linspace(0,max(Radii));
Y = wblpdf(X,Weibull_scale,Weibull_shape);
histogram(Radii,30,'Normalization','pdf')
plot(X,Y, 'LineWidth', 3);
set(gca, 'FontSize', 16)
xlabel('Diameter of particle $\mu m$','Interpreter','latex')
ylabel('Frequency of Diameter','Interpreter','latex')
legend('Actual Distribution', 'Desired Dirstibution')
set(gcf,'color','w');

% save figure: uncomment if needed
% print('Radii_Distribution_SphericalBoundary','-dpdf');
% savefig('Radii_Distribution_SphericalBoundary.fig');                                        

%% Particle Placement Plot 
figure(2)
hold on
axis equal
[x, y, z] = sphere;
List = 1:NSpheres; 
light               
lighting gouraud    
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x + Positions(1,i), Radii(i)*y + Positions(2,i), Radii(i)*z + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
end
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
set(gcf,'color','w');
view([45, 45])

% save figure: uncomment if needed
% print('ParticlePlacement_SphericalBoundary','-dpdf');
% savefig('ParticlePlacement_SphericalBoundary.fig');


%% First parents plot
x_max = BrickSideLengths(1); y_max = BrickSideLengths(2); z_max = BrickSideLengths(3);
x_min = 0; y_min = 0; z_min = 0;
x_max_input = BrickSideLengths(1); y_max_input = BrickSideLengths(2); z_max_input = BrickSideLengths(3);

figure(3)
hold on
axis equal
[x, y, z] = sphere;
List = 1:8; %These are the first parents

surf(HemisphereRadii(1)*x, HemisphereRadii(1)*y + y_max_input/2, HemisphereRadii(1)*z + z_max_input/2,'FaceAlpha',0.8); %First Spherical Boundary
surf(HemisphereRadii(2)*x + x_max_input, HemisphereRadii(2)*y + y_max_input/2, HemisphereRadii(2)*z + z_max_input/2,'FaceAlpha',0.8); %Second Spherical Boundary
light               
lighting gouraud    
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x + Positions(1,i), Radii(i)*y + Positions(2,i), Radii(i)*z + Positions(3,i),'EdgeColor','none','Facecolor','r')
end
xlim([0 x_max])
ylim([0 y_max])
zlim([0 z_max])
plot3([x_min, x_max],[y_min, y_min],[z_min, z_min],'k')
plot3([x_min, x_max],[y_max, y_max],[z_min, z_min],'k')
plot3([x_min, x_min],[y_min, y_max],[z_min, z_min],'k')
plot3([x_max, x_max],[y_min, y_max],[z_min, z_min],'k')
plot3([x_min,x_min],[y_min,y_min],[z_min,z_max],'k')
plot3([x_max,x_max],[y_min,y_min],[z_min,z_max],'k')
plot3([x_max,x_max],[y_max,y_max],[z_min,z_max],'k')
plot3([x_min,x_min],[y_max,y_max],[z_min,z_max],'k')
plot3([x_min, x_max],[y_min, y_min],[z_max, z_max],'k')
plot3([x_min, x_max],[y_max, y_max],[z_max, z_max],'k')
plot3([x_min, x_min],[y_min, y_max],[z_max, z_max],'k')
plot3([x_max, x_max],[y_min, y_max],[z_max, z_max],'k')
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view([30, 30])

% save figure: uncomment if needed
% print('FirstParents_SphericalBoundary','-dpdf');
% savefig('FirstParents_SphericalBoundary.fig');

%% Plot the sphere filling and the domain boundaries
figure(4)
hold on
axis equal
[x, y, z] = sphere;
List = 1:NSpheres; 
light              
lighting gouraud   
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x + Positions(1,i), Radii(i)*y + Positions(2,i), Radii(i)*z + Positions(3,i),'EdgeColor','none')
end
surf(HemisphereRadii(1)*x, HemisphereRadii(1)*y + y_max_input/2, HemisphereRadii(1)*z + z_max_input/2,'FaceAlpha',0.5,'Facecolor','r'); %First Spherical Boundary
surf(HemisphereRadii(2)*x + x_max_input, HemisphereRadii(2)*y + y_max_input/2, HemisphereRadii(2)*z + z_max_input/2,'FaceAlpha',0.5,'Facecolor','r'); %Second Spherical Boundary
xlim([0 x_max])
ylim([0 y_max])
zlim([0 z_max])
plot3([x_min, x_max],[y_min, y_min],[z_min, z_min],'k')
plot3([x_min, x_max],[y_max, y_max],[z_min, z_min],'k')
plot3([x_min, x_min],[y_min, y_max],[z_min, z_min],'k')
plot3([x_max, x_max],[y_min, y_max],[z_min, z_min],'k')
plot3([x_min,x_min],[y_min,y_min],[z_min,z_max],'k')
plot3([x_max,x_max],[y_min,y_min],[z_min,z_max],'k')
plot3([x_max,x_max],[y_max,y_max],[z_min,z_max],'k')
plot3([x_min,x_min],[y_max,y_max],[z_min,z_max],'k')
plot3([x_min, x_max],[y_min, y_min],[z_max, z_max],'k')
plot3([x_min, x_max],[y_max, y_max],[z_max, z_max],'k')
plot3([x_min, x_min],[y_min, y_max],[z_max, z_max],'k')
plot3([x_max, x_max],[y_min, y_max],[z_max, z_max],'k')
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view([30, 30])

% save figure: uncomment if needed
% print('ParticlesAndSphericalBoundaries_SphericalBoundary','-dpdf');
% savefig('ParticlesAndSphericalBoundaries_SphericalBoundary.fig');