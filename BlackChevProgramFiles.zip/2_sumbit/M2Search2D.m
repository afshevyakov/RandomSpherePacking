function [BAD,N,R,P,Parents,num_P,P3,size_P3] = Search2D(p_new,r_new,P,R,N,Parents,num_P,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta, face)
%   Changed Z=0 plane to X=0 plane

BAD = false;

minvalues=[0,0,0];
maxvalues=[x_max,y_max,z_max];

if(face==1) % x=0 plane; need to check y and z boundaries
    indicesXYZ=[2, 3];% directions where checks will be done
elseif (face==2) % y=0 plane; need to check x and z boundaries
    indicesXYZ=[1, 3];
elseif (face==3) % z=0 plane; need to check x and y boundaries
    indicesXYZ=[1, 2];
else    
    BAD = true; return;
end;

minXYZ=minvalues(indicesXYZ)-epsilon; %minimal values for boundaries
maxXYZ=maxvalues(indicesXYZ)+epsilon; %maximal values for boundaries

    
if (p_new(indicesXYZ(1)) > minXYZ(1))&&(p_new(indicesXYZ(1)) < maxXYZ(1)) ...
    &&(p_new(indicesXYZ(2)) > minXYZ(2))&&(p_new(indicesXYZ(2)) < maxXYZ(2))
    
    TEST = vecnorm(P(:,1:N) - p_new) - R(1:N); %Distance between all particles, accounting for radii
    overlap = find(TEST < r_new - epsilon); %All particles that overlap more than epsilon
    
    if size(overlap,2) > 0%Sphere overlaps with particles, the list of particles overlaping with p_new contains elements
        
        BAD = true;
        
    else %Sphere fits with particle, the set of particles overlaping is empty
        Parents(count,:) = []; %Remove parents that spawned p_new
        num_P = num_P - 1; %Accounting for the removed parents
        
        N = N+1;
        P(:,N) = p_new;
        R(N) = r_new;
        
        index = find(TEST < r_new + delta); %All particles delta close to p_new
        size_index = size(index,2);
        
        Parents((num_P+1):(num_P + size_index),:) = [index',N*ones(size_index,1)];
        num_P = num_P + size_index;
        
        Index = sort(index); %Smallest to biggest
        
        BAD = false;
        for count2 = 1:(size_index - 1)
            for count3 = (count2 + 1):size_index
                part_A = Index(count2); part_B = Index(count3); %part_A < part_B
                
                if norm(P(:,part_A) - P(:,part_B)) < R(part_A) + R(part_B) + delta
                    size_P3 = size_P3 + 1; %Adding another triplet to list of 3d parents
                    P3(size_P3,:) = [part_A, part_B, N]; %Form triplet with N(new particle)
                end
                
            end%End of count3
        end%End of count2
    end%End of particle check
    
else %Sphere overlaps with boundary
    BAD = true;
end%End of first boundary check

end%End of function

