%% Matlab script for Example 2: Method 2, using the Gamma distribution
% Produces the sphere filling of the domain and plots of Figure 5
% Required files:
% * Method2GenerateSpheres.m -- main sphere filling routine
% * Auxiliary routine files for Method1GenerateSpheres.m :
%    - M2Position2Xmin.m
%    - M2Position2Ymin.m
%    - M2Position2Zmin.m
%    - M2Position3.m
%    - M2Search2D.m
%    - M2Search3D.m

clear all; close all; clc;

%% Sphere Packing parameters: Gamma distribution

rng(0); %random seed zero: Matlab default

Gamma_scale = 7; % scale parameter theta in the Gamma distribution; dimensional (micrometers)
Gamma_shape = 2;  % shape (k) k in Gamma distribution; dimensionless

%first parameter a: shape; 2nd parameter b: scale
ProbabilityDistribution = makedist('Gamma','a', Gamma_shape ,'b', Gamma_scale);
average_radius = mean(ProbabilityDistribution) %equal to Gamma_shape*Gamma_scale

FaceGoal = 1.0; 
BodyGoal = 0.9; 

%Unit brick: here unit cube
std_length = 30*average_radius; 
BrickSideLengths = [1;1;1] * std_length;

%numbers of cubes in x, y, z directions
BrickNumbers = [2;2;1];

SphereContactParameter = 0.1; 
ParentParameter = 0.5; 

%% Run the sphere generation Method 2 algorithm and save results

tic

[FinalNSpheres, UnitBrickNSpheres, Positions, Radii, Contacts, ListXmin, ListYmin, ListZmin, ListXmax, ListYmax, ListZmax] = ...
  Method2GenerateSpheres( ...
    ProbabilityDistribution, ...
    FaceGoal, BodyGoal, ...
    SphereContactParameter, ParentParameter, ...
    BrickSideLengths, BrickNumbers );

sphere_filling_total_time = toc

save('Example2_Method2_Gamma_Results.mat')

%% Method 2, plot desired vs. actual distribution: Fig.5c

FF=figure(14);
hold on;

%plot histogram of obtained radii
histogram(Radii,30,'Normalization','pdf');

%plot Weibull PDF 
X = linspace(0,max(Radii));
Y = pdf(ProbabilityDistribution,X);
plot(X,Y, 'LineWidth', 3);
set(gca, 'FontSize', 14)
xlabel('Particle radius','Interpreter','latex')
ylabel('Probability density','Interpreter','latex')
legend('Actual', 'Gamma', 'Interpreter','latex', 'location', 'northeast')
hold off

% savefig('Example2_Method2_Gamma_DistributionCurves.fig');
% print('Example2_Method2_Gamma_DistributionCurves','-dpdf');

%% Example 2, Method 2, Unit Brick Plot - open (Fig. 5a)
max_radius=max(Radii);
minimal_sphere_x=-max_radius;
maximal_sphere_x=max(Positions(1,:))+max_radius;
minimal_sphere_y=-max_radius;
maximal_sphere_y=max(Positions(2,:))+max_radius;
minimal_sphere_z=-max_radius;
maximal_sphere_z=max(Positions(3,:))+max_radius;

figure(11)
hold on
axis equal
[x_sph, y_sph, z_sph] = sphere;
percent = 0;
List = 1:UnitBrickNSpheres; %particles to display
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
    
    if mod(count,1000)==0
        percent = 100*(count/UnitBrickNSpheres); %Keeping track of progress
        disp(['Plotting Open Unit Brick ',num2str(percent), '% complete'])
    end
    
end
xlim([0, BrickSideLengths(1)]);
ylim([0, BrickSideLengths(2)]);
zlim([0, BrickSideLengths(3)]);
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view(30, 30);
hold off;

% save as needed
% savefig('Example2_Method2_Gamma_UnitBrickOpen.fig');
% print('Example2_Method2_Gamma_UnitBrickOpen','-dpdf');

%% Example 2, Method 2, Unit Brick Plot - closed (Fig. 5b)
figure(12)
hold on
axis equal
[x_sph, y_sph, z_sph] = sphere;
percent = 0;
List = 1:UnitBrickNSpheres; %particles to display
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
    
    if mod(count,1000)==0
        percent = 100*(count/UnitBrickNSpheres); %Keeping track of progress
        disp(['Plotting Closed Unit Brick ',num2str(percent), '% complete'])
    end
    
end

max_sphere_radius=1.05*max(Radii);
xlim([-max_sphere_radius, BrickSideLengths(1) + max_sphere_radius]);
ylim([-max_sphere_radius, BrickSideLengths(2) + max_sphere_radius]);
zlim([-max_sphere_radius, BrickSideLengths(3) + max_sphere_radius]);
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view(30, 30);
hold off;

% save as needed
% savefig('Example2_Method2_Gamma_UnitBrickClosed.fig');
% print('Example2_Method2_Gamma_UnitBrickClosed','-dpdf');

%% Example 2, Method 2, Total domain - top and bottom faces  (Fig. 5d)

figure(31)
hold on
axis equal
List = ListZmin';
List2 = ListZmax';
light               % create a light
lighting gouraud    % preferred method for lighting curved surfaces
for count = 1:size(List,2)
    i = List(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
end
xlim([minimal_sphere_x, maximal_sphere_x]);
ylim([minimal_sphere_y, maximal_sphere_y]);
zlim([minimal_sphere_z, maximal_sphere_z]);
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');

for count = 1:size(List2,2)
    i = List2(count);
    surf(Radii(i)*x_sph + Positions(1,i), Radii(i)*y_sph + Positions(2,i), Radii(i)*z_sph + Positions(3,i),'EdgeColor','none','FaceLighting','gouraud')
end
xlim([minimal_sphere_x, maximal_sphere_x]);
ylim([minimal_sphere_y, maximal_sphere_y]);
zlim([minimal_sphere_z, maximal_sphere_z]);
xlabel('$x, {\rm \mu m}$', 'Interpreter', 'latex');
ylabel('$y, {\rm \mu m}$', 'Interpreter', 'latex'); 
zlabel('$z, {\rm \mu m}$', 'Interpreter', 'latex');
view([30, 30]);
hold off;

% save as needed
% savefig('Example2_Method2_Gamma_UnitCube_SidesZ.fig');
% print('Example2_Method2_Gamma_UnitCube_SidesZ','-dpdf');

