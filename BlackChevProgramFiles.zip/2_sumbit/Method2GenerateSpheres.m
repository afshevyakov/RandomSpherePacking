function [FinalNSpheres, UnitBrickNSpheres, Positions, Radii, Contacts, ListXmin, ListYmin, ListZmin, ListXmax, ListYmax, ListZmax] = Method2GenerateSpheres(ProbabilityDistr, FaceGoal, BodyGoal, SphereContactParameter, ParentParameter, BrickSideLengths, BrickNumbers)


output_percent_step=10;

average = mean(ProbabilityDistr);

epsilon = SphereContactParameter*average;
delta = ParentParameter*average;

xBricks = BrickNumbers(1);
yBricks = BrickNumbers(2);
zBricks = BrickNumbers(3);

x_min = 0;
y_min = 0;
z_min = 0;

x_max = BrickSideLengths(1);
y_max = BrickSideLengths(2);
z_max = BrickSideLengths(3);

Radii(1:8) = average;
Positions(:,1) = [0;0;0];
Positions(:,2) = [0;y_max;0];
Positions(:,3) = [x_max;0;0];
Positions(:,4) = [x_max;y_max;0];
Positions(:,5) = [0;0;z_max];
Positions(:,6) = [0;y_max;z_max];
Positions(:,7) = [x_max;0;z_max];
Positions(:,8) = [x_max;y_max;z_max];

Ninit=25; %initial size of arrays
NMaxFail=50; % number after which we don't hope any longer to fit a current sphere

disp('--- Starting sphere filling of the specified domain: Method 2 ---');
disp('* Probability distribution and its parameters:');
disp(ProbabilityDistr);
fprintf('* Average sphere radius: %2.5f [physical units]\n', average);
fprintf('* Dimensions of the unit brick [same physical units]: %2.5f x %2.5f x %2.5f\n', x_max, y_max, z_max);
fprintf('* Numbers of unit bricks to be used to define the domain V -- %2.5f along x, %2.5f along y, %2.5f along z\n', xBricks, yBricks, zBricks);
fprintf('* Dimensions of the domain V to be filled [same physical units]: %2.5f x %2.5f x %2.5f\n', x_max*xBricks, y_max*yBricks, z_max*zBricks);
fprintf('* Face goal: %2.5f%% of faces to be covered with spheres\n', FaceGoal*100);
fprintf('* Body goal: %2.5f%% of volume to be occupied with spheres\n\n', BodyGoal*100);
fprintf('* Sphere contact parameter: %2.5f \n', SphereContactParameter);
fprintf('* Parent parameter: %2.5f \n\n', ParentParameter);


disp('--- Filling unit brick edges and faces ... ---');

%% Filling Edges

% 1) Along y... from (0,0,0) to (0,y_max,0)
n = 1;
D = [2*average];
while sum(D) <= y_max
   n = n + 1;
   D(n) = 2*random(ProbabilityDistr);%These are diameters
end
test = sum(D) - y_max; %Extra diameter
TEST = (test/(n-1))*ones(1,(n-1)); %Equally removing extra diameter between each sphere 
D(2:n) = D(2:n) - TEST; %Now diameters should fit perfectly between each corner spheres

size_E = n-1; %Number of particles along edge
FinalNSpheres = 8 + size_E; %Number of particles
Radii(8+1:8+size_E) = (1/2)*D(2:n); %Distribution draws diameter, to get radii need to divide by 2
Positions(:,9) = [0;Radii(1) + Radii(9);0];
E1 = 9:(FinalNSpheres);
for count = 10:FinalNSpheres %Placement of edge particels
  Positions(:,count) = Positions(:,(count-1)) + [0;Radii(count-1)+Radii(count);0]; %Placement is based off previous particle, plus previous and current radii
end

RE = Radii(E1);
PEY = Positions(:,E1); %E1 is an Y edge

 % ....  and 4 copies (translated in x, z, and x+z)

  
Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEY + [x_max;0;0];
Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
E2 = (FinalNSpheres+1):(FinalNSpheres+size_E);
FinalNSpheres = FinalNSpheres+size_E;

Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEY + [0;0;z_max];
Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
E3 = (FinalNSpheres+1):(FinalNSpheres+size_E);
FinalNSpheres = FinalNSpheres+size_E;

Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEY + [x_max;0;z_max];
Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
E4 = (FinalNSpheres+1):(FinalNSpheres+size_E);
FinalNSpheres = FinalNSpheres+size_E;

 
 %-----------------------
 
 % 2) Along x: [0,0,0] to [x_max,0,0]
n = 1;
D = [2*average];

while sum(D) <= x_max
   n = n + 1;
   D(n) = 2*random(ProbabilityDistr);%These are diameters
end
test = sum(D) - x_max; %Extra diameter
TEST = (test/(n-1))*ones(1,(n-1)); %Equally removing extra diameter between each sphere 
D(2:n) = D(2:n) - TEST; %Now diameters should fit perfectly between each corner spheres

size_E = n-1; %Number of particles along edge
FinalNSpheresPrev = FinalNSpheres; %Number of particles
FinalNSpheres = FinalNSpheres + size_E; %Number of particles
Radii(FinalNSpheresPrev+1:FinalNSpheres) = (1/2)*D(2:n); %Distribution draws diameter, to get radii need to divide by 2
Positions(:,FinalNSpheresPrev+1) = [Radii(1) + Radii(FinalNSpheresPrev+1);0;0];
 E1 = (FinalNSpheresPrev+1):(FinalNSpheres);
 for count = (FinalNSpheresPrev+2):FinalNSpheres %Placement of edge particels
    Positions(:,count) = Positions(:,(count-1)) + [Radii(count-1)+Radii(count);0;0]; %Placement is based off previous particle, plus previous and current radii
 end
 
 % ....  and 4 copies (translated in y, z, and y+z)
 RE = Radii(E1);
 PEX = Positions(:,E1); %E1 is an Y edge

 Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEX + [0;y_max;0];
 Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
 E6 = (FinalNSpheres+1):(FinalNSpheres+size_E);
 FinalNSpheres = FinalNSpheres+size_E;
 
 Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEX + [0;0;z_max];
 Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
 E7 = (FinalNSpheres+1):(FinalNSpheres+size_E);
 FinalNSpheres = FinalNSpheres+size_E;
 
 Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEX + [0;y_max;z_max];
 Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
 E8 = (FinalNSpheres+1):(FinalNSpheres+size_E);
 FinalNSpheres = FinalNSpheres+size_E;


  % 2) Along z: [0,0,0] to [0,0,z_max]
n = 1;
D = [2*average];

while sum(D) <= z_max
   n = n + 1;
   D(n) = 2*random(ProbabilityDistr);%These are diameters
end
test = sum(D) - z_max; %Extra diameter
TEST = (test/(n-1))*ones(1,(n-1)); %Equally removing extra diameter between each sphere 
D(2:n) = D(2:n) - TEST; %Now diameters should fit perfectly between each corner spheres

size_E = n-1; %Number of particles along edge
FinalNSpheresPrev = FinalNSpheres; %Number of particles
FinalNSpheres = FinalNSpheres + size_E; %Number of particles
Radii(FinalNSpheresPrev+1:FinalNSpheres) = (1/2)*D(2:n); %Distribution draws diameter, to get radii need to divide by 2
Positions(:,FinalNSpheresPrev+1) = [0;0;Radii(1) + Radii(FinalNSpheresPrev+1)];
 E1 = (FinalNSpheresPrev+1):(FinalNSpheres);
 for count = (FinalNSpheresPrev+2):FinalNSpheres %Placement of edge particels
    Positions(:,count) = Positions(:,(count-1)) + [0;0;Radii(count-1)+Radii(count)]; %Placement is based off previous particle, plus previous and current radii
 end
 
 % ....  and 4 copies (translated in y, z, and y+z)
 RE = Radii(E1);
 PEZ = Positions(:,E1); %E1 is an Y edge
 
 Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEZ + [0;y_max;0];
 Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
 E10 = (FinalNSpheres+1):(FinalNSpheres+size_E);
 FinalNSpheres = FinalNSpheres+size_E;
 
  Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEZ + [x_max;0;0];
 Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
 E11 = (FinalNSpheres+1):(FinalNSpheres+size_E);
 FinalNSpheres = FinalNSpheres+size_E;
 
  Positions(:,(FinalNSpheres + 1):(FinalNSpheres + size_E)) = PEZ + [x_max;y_max;0];
 Radii((FinalNSpheres+1):(FinalNSpheres + size_E)) = RE;
 E12 = (FinalNSpheres+1):(FinalNSpheres+size_E);
 FinalNSpheres = FinalNSpheres+size_E;
 
% -- Fill particle lists on faces x=0, y=0, z=0 
ListXmin = find(Positions(1,:)==0); %All particles that are on the Xmin face
ListYmin = find(Positions(2,:)==0); %All particles that are on the Ymin face
ListZmin = find(Positions(3,:)==0); %All particles that are on the Zmin face


%%%%%%%%%%%%%%%%%%% -- edge generation finished - %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('--- Unit brick edge generation finished ---');



%% Filling Faces


FaceAreas=zeros(1,3);
SphereAreas=zeros(1,3);

%% Z=0 face
% -- parents:
 
 CDP = false(FinalNSpheres); %Contact Matrix
for count = 1:size(ListZmin,2) %Run through all particles on Zmin to find parents
    part = ListZmin(count);
    
    TEST = vecnorm(Positions(:,part) - Positions) - Radii; 
    index = find((TEST > -Radii(part))&(TEST < Radii(part) + delta)); %First condition is to exclude the particle itself, and the second is to check for closeness
    
    index_Zmin = intersect(index,ListZmin);%These are the particles that are on the Zmin face and are possible parents with particle 'part'
    
    for count2 = 1:size(index_Zmin,2) %Running through indices of found particles
        i = index_Zmin(count2);
        
       CDP(part,i) = true; CDP(i,part) = true; %Probably redundant
        
    end
end

CDP_U = triu(CDP); %Triangularizing the matrix to ensure were not double counting contacts
[i,j] = find(CDP_U == true); %Finding the indices of contacts and reducing it to a list to save space
P2 = [i, j]; %List of contacts, particle i is in contact with particle j
size_P2 =size(P2,1); %size of the list of contacts

% -- Filling Zmin Face:
  
P3 = zeros(Ninit,3); %Indicies of potential parents in 3D 
size_P3 = 0; %Right now there are zero in the list

ThrownAway = zeros(1,Ninit); %Keeps track of thrown away particles 
num_ThrownAway = 0;

F = zeros(1,Ninit); %Particles on Face 
size_F = 0;

AreaF = pi*sum(Radii(ListZmin).^2);

r_new = random(ProbabilityDistr); %first radius we'll try to fit, Need to divide by 2

FAIL = uint16(0); %FAIL will keep track of the number of times a set of partents the new particle has tried to place with. If this gets too large and the particle still doesnt fit it is likely that it wont fit anywhere and a new particle needs to be drawn
FAIL2 = 0; %Keeping track of number of particles that didn't fit with any parents. If this gets too high it is likely that no more particles will find a place. Might need to play around to figure out optimal value for this parameter

prev_percent=0;

ThisFaceArea=x_max*y_max;

while (AreaF < ThisFaceArea*FaceGoal)&&(FAIL2 < NMaxFail) 
    
    for count = 1:size_P2 %Going through list of parents on Zmin face
       
        i = P2(count,1); j = P2(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;0;1]);%Crossed with unit vector in z direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M2Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,P2,size_P2,P3,size_P3] = M2Search2D(p_new,r_new,Positions,Radii,...
                        FinalNSpheres,P2,size_P2,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta, ...
                        3);%Determines if new particle overlaps any other particles; z-direction
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M2Position2Zmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,P2,size_P2,P3,size_P3] = M2Search2D(p_new,r_new,Positions,Radii,...
                FinalNSpheres,P2,size_P2,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta, ...
                3); %z-direction
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot

                
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
                r_new = random(ProbabilityDistr);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                size_F = size_F + 1; %increasing size of F
                F(size_F) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaF = AreaF + pi*(Radii(FinalNSpheres))^2; %New particle increases area of Zmin taken up
                
            end
            
        else %Particle fit in 1st spot
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            r_new = random(ProbabilityDistr); 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            size_F = size_F + 1; %increasing size of F
            F(size_F) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaF = AreaF + pi*(Radii(FinalNSpheres))^2;
        end
        
        if AreaF > ThisFaceArea*FaceGoal %If condition is met in middle of cycle this wil break it
            break
        end
        
        if FAIL > size_P2 %Tried every set of parents on face
            FAIL = 0;
            FAIL2 = FAIL2 + 1;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new; %Keeping track of thrown away spheres
            r_new = r_new*(0.9); %Shrinking particle, no point grabbing random size b/c if its any bigger it wont fit
        end
        
    end
    
    ratioZmin = AreaF/ThisFaceArea; %Output to keep user updated on progress
    
    percent = round( min( [100,100*(AreaF/(ThisFaceArea*FaceGoal))]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the face z=0: ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end

FaceAreas(3)=ThisFaceArea;
SphereAreas(3)=AreaF;

F = F(1:size_F);

F1 = F;
FZ = Positions(:,F);
RF = Radii(F);

%copy to opposite face: 

Positions(:,(FinalNSpheres+1):(FinalNSpheres+size_F)) = FZ + [0;0;z_max];
Radii((FinalNSpheres+1):(FinalNSpheres+size_F)) = RF;
F2 = (FinalNSpheres+1):(FinalNSpheres+size_F);
FinalNSpheres = FinalNSpheres+size_F;

% disp('** Z=0, Max faces done **');

%% X=0 face
% -- parents:
 
 CDP = false(FinalNSpheres); %Contact Matrix
for count = 1:size(ListXmin,2) %Run through all particles on Xmin to find parents
    part = ListXmin(count);
    
    TEST = vecnorm(Positions(:,part) - Positions) - Radii; 
    index = find((TEST > -Radii(part))&(TEST < Radii(part) + delta)); %First condition is to exclude the particle itself, and the second is to check for closeness
    
    index_Xmin = intersect(index,ListXmin);%These are the particles that are on the Xmin face and are possible parents with particle 'part'
    
    for count2 = 1:size(index_Xmin,2) %Running through indices of found particles
        i = index_Xmin(count2);
        
       CDP(part,i) = true; CDP(i,part) = true; %Probably redundant
        
    end
end

CDP_U = triu(CDP); %Triangularizing the matrix to ensure were not double counting contacts
[i,j] = find(CDP_U == true); %Finding the indices of contacts and reducing it to a list to save space
P2 = [i, j]; %List of contacts, particle i is in contact with particle j
size_P2 =size(P2,1); %size of the list of contacts

% -- Filling Xmin Face:
  
P3 = zeros(Ninit,3); %Indicies of potential parents in 3D 
size_P3 = 0; %Right now there are zero in the list

ThrownAway = zeros(1,Ninit); %Keeps track of thrown away particles 
num_ThrownAway = 0;

F = zeros(1,Ninit); %Particles on Face 
size_F = 0;

AreaF = pi*sum(Radii(ListXmin).^2);

r_new = random(ProbabilityDistr); %first radius we'll try to fit, Need to divide by 2

FAIL = 0; %FAIL will keep track of the number of times a set of partents the new particle has tried to place with. If this gets too large and the particle still doesnt fit it is likely that it wont fit anywhere and a new particle needs to be drawn
FAIL2 = 0; %Keeping track of number of particles that didn't fit with any parents. If this gets too high it is likely that no more particles will find a place. Might need to play around to figure out optimal value for this parameter

prev_percent=0;

ThisFaceArea=y_max*z_max;

while (AreaF < ThisFaceArea*FaceGoal)&&(FAIL2 < NMaxFail) 
    
    for count = 1:size_P2 %Going through list of parents on Xmin face
       
        i = P2(count,1); j = P2(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[1;0;0]);%Crossed with unit vector in x direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M2Position2Xmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,P2,size_P2,P3,size_P3] = M2Search2D(p_new,r_new,Positions,Radii,...
            FinalNSpheres,P2,size_P2,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta,...
            1);%Determines if new particle overlaps any other particles; x-direction
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M2Position2Xmin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,P2,size_P2,P3,size_P3] = M2Search2D(p_new,r_new,Positions,Radii,...
                FinalNSpheres,P2,size_P2,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta,...
                1); %x-direction
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot

                
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
                r_new = random(ProbabilityDistr);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                size_F = size_F + 1; %increasing size of F
                F(size_F) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaF = AreaF + pi*(Radii(FinalNSpheres))^2; %New particle increases area of Xmin taken up
                
            end
            
        else %Particle fit in 1st spot
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            r_new = random(ProbabilityDistr); 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            size_F = size_F + 1; %increasing size of F
            F(size_F) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaF = AreaF + pi*(Radii(FinalNSpheres))^2;
        end
        
        if AreaF > ThisFaceArea*FaceGoal %If condition is met in middle of cycle this wil break it
            break
        end
        
        if FAIL > size_P2 %Tried every set of parents on face
            FAIL = 0;
            FAIL2 = FAIL2 + 1;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new; %Keeping track of thrown away spheres
            r_new = r_new*(0.9); %Shrinking particle, no point grabbing random size b/c if its any bigger it wont fit
        end
        
    end
    
    ratioXmin = AreaF/ThisFaceArea; %Output to keep user updated on progress
    
    percent = round( min( [100,100*(AreaF/(ThisFaceArea*FaceGoal))]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the face x=0: ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end


FaceAreas(1)=ThisFaceArea;
SphereAreas(1)=AreaF;

F = F(1:size_F);

F1 = F;
FX = Positions(:,F);
RF = Radii(F);

%copy to opposite face: 
Positions(:,(FinalNSpheres+1):(FinalNSpheres+size_F)) = FX + [x_max;0;0];
Radii((FinalNSpheres+1):(FinalNSpheres+size_F)) = RF;
F4 = (FinalNSpheres+1):(FinalNSpheres+size_F);
FinalNSpheres = FinalNSpheres+size_F;

% disp('** X=0, Max faces done **');

%% Y=0 face
% -- parents:
 
 CDP = false(FinalNSpheres); %Contact Matrix
for count = 1:size(ListYmin,2) %Run through all particles on Ymin to find parents
    part = ListYmin(count);
    
    TEST = vecnorm(Positions(:,part) - Positions) - Radii; 
    index = find((TEST > -Radii(part))&(TEST < Radii(part) + delta)); %First condition is to exclude the particle itself, and the second is to check for closeness
    
    index_Ymin = intersect(index,ListYmin);%These are the particles that are on the Ymin face and are possible parents with particle 'part'
    
    for count2 = 1:size(index_Ymin,2) %Running through indices of found particles
        i = index_Ymin(count2);
        
       CDP(part,i) = true; CDP(i,part) = true; %Probably redundant
        
    end
end

CDP_U = triu(CDP); %Triangularizing the matrix to ensure were not double counting contacts
[i,j] = find(CDP_U == true); %Finding the indices of contacts and reducing it to a list to save space
P2 = [i, j]; %List of contacts, particle i is in contact with particle j
size_P2 =size(P2,1); %size of the list of contacts

% -- Filling Ymin Face:
  
P3 = zeros(Ninit,3); %Indicies of potential parents in 3D 
size_P3 = 0; %Right now there are zero in the list

ThrownAway = zeros(1,Ninit); %Keeps track of thrown away particles 
num_ThrownAway = 0;

F = zeros(1,Ninit); %Particles on Face 
size_F = 0;

AreaF = pi*sum(Radii(ListYmin).^2);

r_new = random(ProbabilityDistr); %first radius we'll try to fit, Need to divide by 2

FAIL = 0; %FAIL will keep track of the number of times a set of partents the new particle has tried to place with. If this gets too large and the particle still doesnt fit it is likely that it wont fit anywhere and a new particle needs to be drawn
FAIL2 = 0; %Keeping track of number of particles that didn't fit with any parents. If this gets too high it is likely that no more particles will find a place. Might need to play around to figure out optimal value for this parameter

prev_percent=0;

ThisFaceArea=x_max*z_max;

while (AreaF < ThisFaceArea*FaceGoal)&&(FAIL2 < NMaxFail) 
    
    for count = 1:size_P2 %Going through list of parents on Ymin face
       
        i = P2(count,1); j = P2(count,2);
        NEXT = false; NEXT2 = false;
        
        n_hat = (Positions(:,i)-Positions(:,j))/norm(Positions(:,i)-Positions(:,j));
        t_hat = cross(n_hat,[0;1;0]);%Crossed with unit vector in y direction
        x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(t_hat);
        
        fun = @(x) M2Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
        [NEXT,FinalNSpheres,Radii,Positions,P2,size_P2,P3,size_P3] = M2Search2D(p_new,r_new,Positions,Radii,...
            FinalNSpheres,P2,size_P2,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta,...
            2);%Determines if new particle overlaps any other particles, y-direction
        
        if NEXT == true %Particle didn't fit
            
            x_0 = Positions(:,j) + Radii(j)*(n_hat) + (r_new)*(-t_hat); %For this new x_0 will start in negative t_hat direciton
            
            fun = @(x) M2Position2Ymin(x,Positions(:,i),Positions(:,j),Radii(i),Radii(j),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
            %Need to check if 2nd spot works
            [NEXT2,FinalNSpheres,Radii,Positions,P2,size_P2,P3,size_P3] = M2Search2D(p_new,r_new,Positions,Radii,...
                FinalNSpheres,P2,size_P2,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta,...
                2); % y-direction
            
            if NEXT2 == true %particle didnt fit in 2nd spot
                
                FAIL = FAIL + 1; %move onto next parents
                
            else %particle fit in 2nd spot

                
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
                r_new = random(ProbabilityDistr);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                size_F = size_F + 1; %increasing size of F
                F(size_F) = FinalNSpheres; %Add added sphere to list
                FAIL = 0; %since sphere worked reset FAIL count
                
                AreaF = AreaF + pi*(Radii(FinalNSpheres))^2; %New particle increases area of Ymin taken up
                
            end
            
        else %Particle fit in 1st spot
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            r_new = random(ProbabilityDistr); 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            size_F = size_F + 1; %increasing size of F
            F(size_F) = FinalNSpheres; %Add added sphere to list
            FAIL = 0; %since sphere worked reset FAIL count
            
            AreaF = AreaF + pi*(Radii(FinalNSpheres))^2;
        end
        
        if AreaF > ThisFaceArea*FaceGoal %If condition is met in middle of cycle this wil break it
            break
        end
        
        if FAIL > size_P2 %Tried every set of parents on face
            FAIL = 0;
            FAIL2 = FAIL2 + 1;
            num_ThrownAway = num_ThrownAway + 1;
            ThrownAway(num_ThrownAway) = r_new; %Keeping track of thrown away spheres
            r_new = r_new*(0.9); %Shrinking particle, no point grabbing random size b/c if its any bigger it wont fit
        end
        
    end
    
    ratioYmin = AreaF/ThisFaceArea; %Output to keep user updated on progress
    
    percent = round( min( [100,100*(AreaF/(ThisFaceArea*FaceGoal))]) );
    
    if(percent-prev_percent>=output_percent_step)
        disp(['Generating spheres along the face y=0: ',num2str(percent), '% complete'])
        prev_percent=percent;
    end
    
end

FaceAreas(2)=ThisFaceArea;
SphereAreas(2)=AreaF;

F = F(1:size_F);

F1 = F;
FY = Positions(:,F);
RF = Radii(F);

%copy to opposite face: 

Positions(:,(FinalNSpheres+1):(FinalNSpheres+size_F)) = FY + [0;y_max;0];
Radii((FinalNSpheres+1):(FinalNSpheres+size_F)) = RF;
F6 = (FinalNSpheres+1):(FinalNSpheres+size_F);
FinalNSpheres = FinalNSpheres+size_F;

% disp('** Y=0, Max faces done **');

disp('--- Unit brick face generation complete ---');
fprintf('* Covered face area: %2.5f%% of the specified face goal\n\n', 100*sum(SphereAreas)/sum(FaceAreas));



%% Finding 3D parents
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Finding Parents to fill body%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('--- Filling unit brick volume ... ---');

P3 = zeros(Ninit,3); %10000
size_P3 = 0;

for count = 1:FinalNSpheres %Run through every particle
    TEST = vecnorm(Positions(:,count)-Positions) - Radii;
    index = find((TEST > -Radii(count))&(TEST < Radii(count) + delta));
    size_index = size(index,2);
    
    for count2 = 1:(size_index - 1)
        for count3 = (count2 + 1):(size_index)
            
            j = index(count2); k = index(count3);
            
            if norm(Positions(:,j)-Positions(:,k)) < Radii(j) + Radii(k) + delta %count2 and count3 are close enought to be parents with count
            order = sort([count,j,k]); %Will give the 3 particles in order
            
            if (ismember(order,P3,'rows')==false) %This group isnt in P3 yet
               size_P3 = size_P3 + 1;
               P3(size_P3,:) = order;
            end
            end%Of distance check between count2 and count3
            
        end%End of count3 loop
        
    end%End of coun2
    
end%End of count loop


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Filling Body
%%%%%%%%%%%%%%%%%%%%%%%%%Filling Body%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prev_percentV=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
r_new = random(ProbabilityDistr); %first radius we'll try to fit
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

B = zeros(1,Ninit); %This will store indicies of particles in body 1000
size_B = 0;

TotalVolume = x_max*y_max*z_max;
V = (4*pi/3)*(Radii.^3); %Volume of all placed spheres
SphereVolume = sum(V);

FAIL = 0; %FAIL will keep track of the number of times a set of partents the new particle has tried to place with. If this gets too large and the particle still doesnt fit it is likely that it wont fit anywhere and a new particle needs to be drawn
FAIL2 = 0; %Keeping track of number of particles that didn't fit with any parents. If this gets too high it is likely that no more particles will find a place. Might need to play around to figure out optimal value for this parameter

STEP = 0;
while ((SphereVolume)/(TotalVolume) < BodyGoal) && (FAIL2 < NMaxFail)  
    
    STEP = STEP + 1;
    for count = 1:size_P3
        
        NEXT = false; NEXT2 = false; %Resetting the NEXT values with new paretns, will only become true if they p_new fails test
        I = P3(count,1); J = P3(count,2); K = P3(count,3);
        
        Centeroid = [(Positions(1,I) + Positions(1,J) + Positions(1,K))/3; (Positions(2,I) + Positions(2,J) + Positions(2,K))/3; (Positions(3,I) + Positions(3,J) + Positions(3,K))/3;];
        P_ij = (Positions(:,J) - Positions(:,I))/norm(Positions(:,J) - Positions(:,I));
        P_ik = (Positions(:,K) - Positions(:,I))/norm(Positions(:,K) - Positions(:,I));
        t_hat = cross(P_ij, P_ik);
        
        x_0 = Centeroid + (r_new)*(t_hat);
        
        fun = @(x) M2Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
        options = optimoptions('fsolve','Display','none');
        p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
        
%         Checking if particle fits
        [NEXT,FinalNSpheres,Radii,Positions,P3,size_P3] = M2Search3D(p_new,r_new,Positions,Radii,FinalNSpheres,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta);
        
        if NEXT == true %Particle didn't fit in 1st spot
            
            x_0 = Centeroid + (r_new)*(-t_hat); %x_0 is on opposite side of plane,
            
            fun = @(x) M2Position3(x,Positions(:,I),Positions(:,J),Positions(:,K),Radii(I),Radii(J),Radii(K),r_new);
            options = optimoptions('fsolve','Display','none');
            p_new = fsolve(fun,x_0,options);  %This determines the location of child particle
            
% %             Checking if new particle fits
            [NEXT2,FinalNSpheres,Radii,Positions,P3,size_P3] = M2Search3D(p_new,r_new,Positions,Radii,FinalNSpheres,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta);
            
            if NEXT2 == true %Particle didnt fit in 2nd spot
                FAIL = FAIL + 1;
            else %Particle fit in 2nd spot
                SphereVolume = SphereVolume + (4*pi/3)*((Radii(FinalNSpheres)).^3); %New sphere is added to the total sphere volume
               
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                r_new = random(ProbabilityDistr);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                size_B = size_B+1;
                B(size_B) = FinalNSpheres;
                FAIL = 0; %Since p_new fit need to reset FAIL count
            end
        else %Particle fit in 1st spot
            SphereVolume = SphereVolume + (4*pi/3)*((Radii(FinalNSpheres)).^3); %New sphere is added to the total sphere volume
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            r_new = random(ProbabilityDistr);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            size_B = size_B+1;
            B(size_B) = FinalNSpheres;
            FAIL = 0; %Since p_new fit need to reset FAIL count
        end
        
        
        if FAIL >= size_P3/2 %Tried Every Set of Parents
            num_ThrownAway = num_ThrownAway + 1; %index and count of spheres thrown away
            ThrownAway(num_ThrownAway) = r_new; %Keep track of sphere discarded
            r_new = r_new*(0.9);
            FAIL = 0; %Reset FAIL count
            FAIL2 = FAIL2 + 1;
        end
        
        if (SphereVolume)/(TotalVolume) >= BodyGoal
            break
        end
        
    end
    
    ratio = (SphereVolume)/(TotalVolume);
    %percentV = ratio/BodyGoal*100;
    percentV = round( min( [100, ratio/BodyGoal*100 ]) );

	if(percentV-prev_percentV>=output_percent_step) 
        disp(['Generating spheres in the domain bulk ',num2str(percentV), '% complete']);
        prev_percentV=percentV;
    end
   
end

disp('--- Unit brick volume generation complete ---');

fprintf('* Covered volume: %2.5f%% of specified body goal\n\n', ratio*100);

disp('--- Filling total volume ... ---');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %% Using Unit Brick To Build Larger Structure


Number1 = FinalNSpheres;
ListXmin = find(Positions(1,:)==0);  %This is list of every particle that is placed on the Xmin face
size_ListXmin = size(ListXmin,2);

ListXadd = setdiff(1:FinalNSpheres,ListXmin); %This is the list of every particle that is NOT on Xmin face, This list will be used to determine which particle should be placed next to the Brick so that theres no overlap
size_ListXadd = size(ListXadd,2);

P_new = Positions(:,ListXadd); %These are the partilces that will be added, there should be no overlap with face of previous Brick
R_new = Radii(ListXadd); 

for count = 1:xBricks-1 %Number of Bricks that are to be added. Total number: xBricks
    Positions(:,FinalNSpheres+1:FinalNSpheres+size_ListXadd) = P_new + (count)*[x_max;0;0]; %New particles are the ones that are not on Xmin face, and they are offest x_max so that they fit next to previous Brick
    Radii(FinalNSpheres+1:FinalNSpheres+size_ListXadd) = R_new; %Radii of new particles
    FinalNSpheres = FinalNSpheres + size_ListXadd;
    
end


Number2 = FinalNSpheres;

ListYmin = find(Positions(2,:)==0);  %This is list of every particle that is placed on the Ymin face
size_ListYmin = size(ListYmin,2);

ListYadd = setdiff(1:FinalNSpheres,ListYmin); %This is the list of every particle that is NOT on Ymin face, This list will be used to determine which particle should be placed next to the Brick so that theres no overlap
size_ListYadd = size(ListYadd,2);

P_new = Positions(:,ListYadd); 
R_new = Radii(ListYadd); 

for count = 1:yBricks-1 %Number of Bricks that are to be added. Total number: yBricks
    Positions(:,FinalNSpheres+1:FinalNSpheres+size_ListYadd) = P_new + (count)*[0;y_max;0]; %New particles are the ones that are not on Xmin face, and they are offest x_max so that they fit next to previous Brick
    Radii(FinalNSpheres+1:FinalNSpheres+size_ListYadd) = R_new; %Radii of new particles
    FinalNSpheres = FinalNSpheres + size_ListYadd;
    
end


Number3 = FinalNSpheres; 
ListZmin = find(Positions(3,:)==0);  %This is list of every particle that is placed on the Zmin face
size_ListZmin = size(ListZmin,2);

ListZadd = setdiff(1:FinalNSpheres,ListZmin); %This is the list of every particle that is NOT on Zmin face, This list will be used to determine which particle should be placed next to the Brick so that theres no overlap
size_ListZadd = size(ListZadd,2);

P_new = Positions(:,ListZadd); 
R_new = Radii(ListZadd); 

for count = 1:zBricks-1 %Number of Bricks that are to be added. Total number: zBricks
    Positions(:,FinalNSpheres+1:FinalNSpheres+size_ListZadd) = P_new + (count)*[0;0;z_max]; %New particles are the ones that are not on Xmin face, and they are offest x_max so that they fit next to previous Brick
    Radii(FinalNSpheres+1:FinalNSpheres+size_ListZadd) = R_new; %Radii of new particles
    FinalNSpheres = FinalNSpheres + size_ListZadd;
    
end

disp('--- Total volume generation complete ---');
disp('--- Computing contacting pairs...  ---');

%% Contacts

Contacts = int32(zeros(FinalNSpheres,2));
size_Contacts = 0;
for count = 1:FinalNSpheres
    
    part = count;
    
    TEST = vecnorm(Positions(:,part) - Positions) - Radii;
    index = find((TEST > -Radii(part))&(TEST < Radii(part) + epsilon)); %All particles within epsilon of part
    
    for count2 = 1:size(index,2) %setting all indecies from idex to true
        i = index(count2);
        
        pair = sort([part,i]); 
        size_Contacts = size_Contacts + 1;
        Contacts(size_Contacts,:) = pair;
    end
    
    
end
Contacts = unique(Contacts,'rows');





%%Boundary Contacts

ListXmin = find(Positions(1,:)==0)';
ListYmin = find(Positions(2,:)==0)';
ListZmin = find(Positions(3,:)==0)';
ListXmax = find(Positions(1,:)== x_max*xBricks)';
ListYmax = find(Positions(2,:)== y_max*yBricks)';
ListZmax = find(Positions(3,:)== z_max*zBricks)';

UnitBrickNSpheres = Number1;

disp('--- Contacting pairs computation complete ---');
disp('--- All done! ---');

end

