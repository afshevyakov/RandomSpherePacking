function [F] = Position2Zmin(x,P1,P2,R1,R2,r_new)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
F = [x(3);
    norm(x - P1) - (r_new + R1);
     norm(x - P2) - (r_new + R2)];
end