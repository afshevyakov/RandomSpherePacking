function [NEXT,N,R,P,P3,size_P3] = Search3D(p_new,r_new,P,R,N,P3,size_P3,count,x_max,y_max,z_max,epsilon,delta)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
NEXT = true;
if (p_new(1) > -epsilon)&&(p_new(1) < x_max + epsilon)&&(p_new(2) > -epsilon)&&(p_new(2) < y_max + epsilon)&&(p_new(3) > -epsilon)&&(p_new(3) < z_max + epsilon)%No boundary overlap
    
    TEST = vecnorm(P(:,1:N) - p_new) - R(1:N);
    overlap = find(TEST < r_new - epsilon);
    
    if size(overlap,2) == 0%No particle overlap
        P3(count,:) = [];
        size_P3 = size_P3 - 1;
        
        N = N+1;
        R(N) = r_new;
        P(:,N) = p_new;
        NEXT = false;
        
        index = find(TEST < r_new + delta); %All particles close to p_new
        size_index = size(index,2);
        Index = sort(index); %Smallest to biggest
        
        for count2 = 1:(size_index - 1)
            for count3 = (count2 + 1):size_index
                part_A = Index(count2); part_B = Index(count3); %part_A < part_B
                
                if norm(P(:,part_A) - P(:,part_B)) < R(part_A) + R(part_B) + delta
                    size_P3 = size_P3 + 1; %Adding another triplet to list of 3d parents
                    P3(size_P3,:) = [part_A, part_B, N]; %Form triplet with N(new particle)
                end
                
            end%End of count3
        end%End of count2
        
        
        
        
    else% particle overlap
        NEXT = true;
    end
    
else%Boundary overlap
    NEXT = true;
end%End of boundary check

end%End of function

